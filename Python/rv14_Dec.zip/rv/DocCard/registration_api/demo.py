from SmsSenderRegistration.SmsSender import SmsSender
import random
from SmsSenderRegistration.SMSChecker import SMSChecker
from os import chdir,mkdir,getcwd



def emailVerificationAtTheTimeOfRegistration(phone_No):
    print(phone_No)
    current = getcwd()
    # print(current)
    chdir(current+"\\registration_api\\SmsSenderRegistration\\")
    # print(getcwd())
    flagChecker = False
    obj = SMSChecker(phone_No)
    flagChecker = obj.main()
    # print(flagChecker)
    if flagChecker:
        flagSender = False
        number = random.randint(1000,9999)
        obj = SmsSender("Card User",str(phone_No)," ","doc.card.royal.vision@gmail.com"," ",str(number))
        flagSender = obj.sendingEmail()
        chdir(current)
        # print(getcwd())
        if flagSender:
            print("Msg is been send  "+ str(number))
        else:
            print("Msg not is been send")

emailVerificationAtTheTimeOfRegistration(9407879317)


