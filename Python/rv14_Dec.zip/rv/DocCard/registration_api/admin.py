from django.contrib import admin
from .models import SenderUserRegistrationModel, ReceiverUserRegistrationModel, SenderKeyModel, RFID_Data_Model

# Register your models here.

@admin.register(SenderUserRegistrationModel)
class SenderAdmin(admin.ModelAdmin):
    list_display = ['id', 'doc_id', 'f_name', 'l_name', 'email_id', 'mobile_no', 'dob', 'user_type', 'gender']

@admin.register(ReceiverUserRegistrationModel)
class ReceiverAdmin(admin.ModelAdmin):
    list_display = ['id', 'doc_id', 'f_name', 'l_name', 'email_id', 'mobile_no', 'dob', 'user_type', 'gender']

@admin.register(SenderKeyModel)
class SenderKeyAdmin(admin.ModelAdmin):
    list_display = ['id', 'doc_id', 'date', 'month', 'year']

@admin.register(RFID_Data_Model)
class RFID_Data_Admin(admin.ModelAdmin):
    list_display = ['id','rfid_id', 'doc_id','date_of_registration']