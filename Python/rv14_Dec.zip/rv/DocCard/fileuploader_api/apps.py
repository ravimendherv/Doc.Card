from django.apps import AppConfig


class FileuploaderApiConfig(AppConfig):
    name = 'fileuploader_api'
