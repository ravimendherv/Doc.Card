from django.db import models

# Create your models here.
# 
#
def user_directory_path(instance, filename,):
    # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
    return '{0}/{1}'.format(doc_id, file_name)
 
class UploardFileModel(models.Model):
    
    doc_id = models.BigIntegerField(unique=True)
    receiver_doc_id =models.BigIntegerField(unique=True)
    input_file = models.FileField(blank=False, null=False)
    file_name = models.CharField(max_length=200)
    timestamp = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.file_name

