from rest_framework.parsers import FileUploadParser, FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework import viewsets
from django.conf import settings
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.core.files.storage import FileSystemStorage
from rest_framework import status
from .models import UploardFileModel
from .serializers import UploadFileSerializer, DownloadFileSerializer, DeleterZipFileSerializer, DeleteFileSerializer
from os import chdir,mkdir,getcwd,remove
from django.http import HttpResponse
from wsgiref.util import FileWrapper
from registration_api.models import SenderKeyModel, ReceiverUserRegistrationModel, SenderUserRegistrationModel
from django.core import serializers
import json
from cryptography.fernet import Fernet
import base64
import shutil
import datetime
import glob






# class FileUploardView(viewsets.ModelViewSet):
#     queryset = UploardFileModel.objects.all()
#     serializer_class = UploadFileSerializer
       
#     def create(self, request):
#         serializer = UploadFileSerializer(data=request.data)
#         x = request.data
#         myfile = x.get('input_file')
#         f_name = str(x.get('file_name'))
#         doc = str(x.get('doc_id'))

#         location = doc +'/' + f_name +'.pdf'
#         if serializer.is_valid():
#             fs = FileSystemStorage()
#             filename = fs.save(location, myfile)
#             uploaded_file_url = fs.url(filename)
#             return Response({"status": "File Uploaded"},status=status.HTTP_200_OK)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# class FileDownloaderView(viewsets.ModelViewSet):
#     queryset = UploardFileModel.objects.all()
#     serializer_class = DownloadFileSerializer
       
#     def create(self, request):
#         serializer = DownloadFileSerializer(data=request.data)
#         x = request.data
#         # myfile = x.get('input_file')
#         f_name = str(x.get('file_name'))
#         doc = str(x.get('doc_id'))

#         location = doc +'/' + f_name +'.zip'
#         if serializer.is_valid():

#             # current = getcwd()
#             # print(current)
#             # chdir(current+"/resouces/")
#         #   print(getcwd())
#             fs = FileSystemStorage()
#             # zip_file = open(location, 'rb')
#             zip_file = fs.open(location)
#             uploaded_file_url = fs.url(zip_file)
#             # chdir(current)
#             response = HttpResponse(FileWrapper(zip_file), content_type='application/zip')
#             response['Content-Disposition'] = 'attachment; filename="%s"' % (f_name + '.zip')
#             return Response({"path":str(uploaded_file_url)}, status=status.HTTP_200_OK)
#             # fs = FileSystemStorage()
#             # filename = fs.save(location, myfile)
#             # uploaded_file_url = fs.url(filename)
#             # return Response([{"STATUS": "FILE UPLOADER", "LINK":""+str(uploaded_file_url)}], status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class FileUploardView(viewsets.ModelViewSet):
    queryset = UploardFileModel.objects.all()
    serializer_class = UploadFileSerializer
    parser_classes = (MultiPartParser,)
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]   
       
    def create(self, request):
        serializer = UploadFileSerializer(data=request.data)
        x = request.data
        myfile = x.get('input_file')
        f_name = str(x.get('file_name'))
        doc = str(x.get('doc_id'))
        doc_int = int(doc)
        # print("____________________________________________###############___________________________")
        # print(x)
        # print(myfile.read())
        # print("____________________________________________###############___________________________")

        try:
            keyQuery = SenderKeyModel.objects.filter(doc_id=doc_int)
        except:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        query = serializers.serialize('json', keyQuery)
        # print(type(query))
        dictData = json.loads(query)
        # print(type(dictData))
        date = str(dictData[0]["fields"]["date"])
        month = str(dictData[0]["fields"]["month"])
        year = str(dictData[0]["fields"]["year"])
        
        location = doc +'/' + f_name +'.pdf'
        if serializer.is_valid():
            with open("resouces/" + doc +'/filenameslist.txt','r') as ef1:
                comparedata = ef1.read()

            comparedata = comparedata.split(",")
      

            if f_name in comparedata:
                return Response({"status":"File Name is Already Exist"}, status=status.HTTP_400_BAD_REQUEST)



            fs = FileSystemStorage()
            filename = fs.save(location, myfile)
            # uploaded_file_url = fs.url(filename)
            fkey =base64.b64encode((doc+doc[::-1]+date+month+year).encode('utf-8'))
            cipher = Fernet(fkey)
            # fileStore = f_name +'.pdf'
            
            with open("resouces/"+location,'rb')as f:
                e_file = f.read()
            
            encrypted_file = cipher.encrypt(e_file)
                        
            with open("resouces/" + doc +'/' + f_name + ".rv",'wb') as ef:
                ef.write(encrypted_file)

            remove("resouces/"+ location) 

            with open("resouces/" + doc +'/filenameslist.txt','a') as ef:
                ef.write(f_name + ",")

            dateTime = str(datetime.datetime.now())

            def write_json(d, storeHistory):
                with open(storeHistory,'w') as f:
                    json.dump(d, f, indent=4)
                
            storeHistory = "resouces/" + doc + "/historyList.json"     
            with open(storeHistory) as json_file:
                d = json.load(json_file)
                temp = d
                y = {"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"uploaded", "Performed" :"By You."}
                temp.append(y)

            write_json(d,storeHistory)

            # with open("resouces/" + doc +'/historyList.json') as ef:
            #     d = json.load(ef)
            #     temp = d['emp_details']
            #     # d = json.load(ef)
            #     # d.update({"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"uploaded"})
            #     # ef.seek(0)
            #     temp.append({"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"uploaded"})
            #     json.dump(d, ef)
                

            return Response({"status": "File Uploaded"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)








class FileDownloaderView(viewsets.ModelViewSet):
    queryset = UploardFileModel.objects.all()
    serializer_class = DownloadFileSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]
       
    def create(self, request):
        serializer = DownloadFileSerializer(data=request.data)
        x = request.data
        # myfile = x.get('input_file')
        f_list = str(x.get('file_name'))
        doc = str(x.get('doc_id'))
        rec = str(x.get('receiver_doc_id'))

        rec_int = int(rec)
        doc_int = int(doc)


        try:
            senderQuery = SenderUserRegistrationModel.objects.filter(doc_id=doc_int)
        except:
            return Response({"status": "Invalid Sender id"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            receiverQuery = ReceiverUserRegistrationModel.objects.filter(doc_id=rec_int)
        except:
            return Response({"status": "Invalid Receiver id"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            keyQuery = SenderKeyModel.objects.filter(doc_id=doc_int)
        except:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


        recQuery = serializers.serialize('json', receiverQuery)
        sendQuery = serializers.serialize('json', senderQuery)


        query = serializers.serialize('json', keyQuery)
        # print(type(query))
        receiverDict = json.loads(recQuery) 
        senderDict = json.loads(sendQuery)

        dictData = json.loads(query)
        # print(type(dictData))
        date = str(dictData[0]["fields"]["date"])
        month =str(dictData[0]["fields"]["month"])
        year = str(dictData[0]["fields"]["year"])

        rf_name = str(receiverDict[0]["fields"]["f_name"])
        rl_name = str(receiverDict[0]["fields"]["l_name"])


        sf_name = str(senderDict[0]["fields"]["f_name"])
        sl_name = str(senderDict[0]["fields"]["l_name"])


        # location = doc +'/' + f_name +'.zip'
        if serializer.is_valid():

            # current = getcwd()
            # print(current)
            # chdir(current+"/resouces/")
        #   print(getcwd())

            f_list = f_list.split(',')
            fkey =base64.b64encode((doc+doc[::-1]+date+month+year).encode('utf-8'))
            cipher = Fernet(fkey)

            dateTime = str(datetime.datetime.now())

            def write_json(d, storeHistory):
                with open(storeHistory,'w') as f:
                    json.dump(d, f, indent=4)
                
            storeHistory = "resouces/" + doc + "/historyList.json"     

            for f_name in f_list:
                location = doc +'/' + f_name +'.rv'
                with open("resouces/" + doc +'/' + f_name +'.rv' ,'rb') as df:
                    encrypted_data = df.read()
                
                decrypted_file = cipher.decrypt(encrypted_data)

                if f_name.endswith("^"):
                    with open("resouces/" + doc +'/output/'+ f_name +'.png','wb') as df:
                        df.write(decrypted_file)
                else:
                    with open("resouces/" + doc +'/output/'+ f_name +'.pdf','wb') as df:
                        df.write(decrypted_file)

                with open(storeHistory) as json_file:
                    d = json.load(json_file)
                    temp = d
                    y = {"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"Sended","Performed" :"TO "+ rf_name +" " + rl_name}
                    temp.append(y)

                write_json(d,storeHistory)
    
            xyz = datetime.datetime.now()
            substr = str(xyz).replace('.','_')
            substr = substr.replace(':','_')
            substr = substr.replace(' ','_')
            substr = substr.replace('-','_')



            #           print(x.strftime("%X"))
    
            zipfilename = doc + "_" + substr + "_DownloadedFiles"

            shutil.make_archive("resouces/" + doc +"/"+ zipfilename, 'zip', "resouces/" + doc +"/output")

            rfiles = glob.glob("resouces/" + doc +"/output/*")
            for rfile in rfiles:
                remove(rfile)
            
            fs = FileSystemStorage()
            # zip_file = open(location, 'rb')
            zip_file = fs.open(doc +"/"+ zipfilename +".zip")
            uploaded_file_url = fs.url(zip_file)
            del zip_file
            # fs.close()


            receiver_storeHistory = "resouces/" + rec + "/historyList.json"

            with open(receiver_storeHistory) as recjson_file:
                da = json.load(recjson_file)
                temp = da
                y = {"name":zipfilename+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"Received","Performed" :"From "+ sf_name +" " + sl_name}
                temp.append(y)

            write_json(da,receiver_storeHistory)

            receiver_notificationList = "resouces/" + rec + "/notificationList.json"

            with open(receiver_notificationList) as notifyjson_file:
                note = json.load(notifyjson_file)
                temp = note
                y = {"name":zipfilename+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","path":str(uploaded_file_url),"from" :sf_name +" " + sl_name + "(" + doc + ")"}
                temp.append(y)

            write_json(note,receiver_notificationList)

            # chdir(current)
            # response = HttpResponse(FileWrapper(zip_file), content_type='application/zip')
            # response['Content-Disposition'] = 'attachment; filename="%s"' % (f_name + '.zip')
            return Response({"status":"File is Sended Successfully"}, status=status.HTTP_200_OK)
            # fs = FileSystemStorage()
            # filename = fs.save(location, myfile)
            # uploaded_file_url = fs.url(filename)
            # return Response([{"STATUS": "FILE UPLOADER", "LINK":""+str(uploaded_file_url)}], status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





class FileDeleterView(viewsets.ModelViewSet):
    queryset = UploardFileModel.objects.all()
    serializer_class = DeleteFileSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]
       
    def create(self, request):
        serializer = DeleteFileSerializer(data=request.data)
        x = request.data
        # myfile = x.get('input_file')
        f_name = str(x.get('file_name'))
        doc = str(x.get('doc_id'))

        location = doc +'/' + f_name +'.rv'
        if serializer.is_valid():

            with open("resouces/" + doc +'/filenameslist.txt','r') as ef1:
                comparedata = ef1.read()
            if ","+ f_name +"," in comparedata:
                comparedata = comparedata.replace(","+f_name+"," , ",")
                print(comparedata+"________________________")
                with open("resouces/" + doc +'/filenameslist.txt','w') as w:
                    w.write(comparedata)
            else:
                return Response({"status": "File not Found"}, status=status.HTTP_400_BAD_REQUEST)


            remove("resouces/" + location)


            dateTime = str(datetime.datetime.now())

            def write_json(d, storeHistory):
                with open(storeHistory,'w') as f:
                    json.dump(d, f, indent=4)
                
            storeHistory = "resouces/" + doc + "/historyList.json"     
            with open(storeHistory) as json_file:
                d = json.load(json_file)
                temp = d
                y = {"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"deleted","Performed" :"By You."}
                temp.append(y)

            write_json(d,storeHistory)

            # current = getcwd()
            # print(current)
            # chdir(current+"/resouces/")
        #   print(getcwd())
            # fs = FileSystemStorage()
            # zip_file = open(location, 'rb')
            # zip_file = fs.open(location)
            # uploaded_file_url = fs.url(zip_file)
            # chdir(current)
            # response = HttpResponse(FileWrapper(zip_file), content_type='application/zip')
            # response['Content-Disposition'] = 'attachment; filename="%s"' % (f_name + '.zip')
            return Response({"status" : "File is Deleted"}, status=status.HTTP_200_OK)
            # fs = FileSystemStorage()
            # filename = fs.save(location, myfile)
            # uploaded_file_url = fs.url(filename)
            # return Response([{"STATUS": "FILE UPLOADER", "LINK":""+str(uploaded_file_url)}], status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)










class ZipFileDeleterView(viewsets.ModelViewSet):
    queryset = UploardFileModel.objects.all()
    serializer_class = DeleterZipFileSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]
       
    def create(self, request):
        serializer = DeleterZipFileSerializer(data=request.data)
        x = request.data
        # myfile = x.get('input_file')
        doc = str(x.get('doc_id'))

        f_name = str(x.get('file_name'))

        rec_doc = str(x.get('receiver_doc_id'))

        note = "resouces/" + rec_doc + "/notificationList.json"
         

        location = "resouces/" + doc +'/' + f_name + ".zip" 
        if serializer.is_valid():

            with open(note,'r') as json_file:
                data = json.load(json_file)
            j = 0
            for i in data:
                if i['name'] == f_name:
                    data.pop(j)
                    # print(data)
                    # print("done")
                j = j + 1

            with open(note,'w') as f:
                json.dump(data, f, indent=4)
                print("Done")


            # fs = FileSystemStorage()
            # fs.delete(location)
            remove(location)

            return Response({"status" : "Zip File is Deleted"}, status=status.HTTP_200_OK)
            # fs = FileSystemStorage()
            # filename = fs.save(location, myfile)
            # uploaded_file_url = fs.url(filename)
            # return Response([{"STATUS": "FILE UPLOADER", "LINK":""+str(uploaded_file_url)}], status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)











class ImageFileUploardView(viewsets.ModelViewSet):
    queryset = UploardFileModel.objects.all()
    serializer_class = UploadFileSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]
       
    def create(self, request):
        serializer = UploadFileSerializer(data=request.data)
        x = request.data
        myfile = x.get('input_file')
        f_name = str(x.get('file_name'))
        doc = str(x.get('doc_id'))
        doc_int = int(doc)
        # print("____________________________________________###############___________________________")
        # print(x)
        # print(myfile.read())
        # print("____________________________________________###############___________________________")

        try:
            keyQuery = SenderKeyModel.objects.filter(doc_id=doc_int)
        except:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        query = serializers.serialize('json', keyQuery)
        # print(type(query))
        dictData = json.loads(query)
        # print(type(dictData))
        date = str(dictData[0]["fields"]["date"])
        month = str(dictData[0]["fields"]["month"])
        year = str(dictData[0]["fields"]["year"])
        
        location = doc +'/' + f_name +'.png'
        if serializer.is_valid():
            with open("resouces/" + doc +'/filenameslist.txt','r') as ef1:
                comparedata = ef1.read()

            comparedata = comparedata.split(",")
      

            if f_name+'^' in comparedata:
                return Response({"status":"File Name is Already Exist"}, status=status.HTTP_400_BAD_REQUEST)



            fs = FileSystemStorage()
            filename = fs.save(location, myfile)
            # uploaded_file_url = fs.url(filename)
            fkey =base64.b64encode((doc+doc[::-1]+date+month+year).encode('utf-8'))
            cipher = Fernet(fkey)
            # fileStore = f_name +'.pdf'
            
            with open("resouces/"+location,'rb')as f:
                e_file = f.read()
            
            encrypted_file = cipher.encrypt(e_file)
                        
            with open("resouces/" + doc +'/' + f_name + ".rv",'wb') as ef:
                ef.write(encrypted_file)

            remove("resouces/"+ location) 

            with open("resouces/" + doc +'/filenameslist.txt','a') as ef:
                ef.write(f_name + ",")

            dateTime = str(datetime.datetime.now())

            def write_json(d, storeHistory):
                with open(storeHistory,'w') as f:
                    json.dump(d, f, indent=4)
                
            storeHistory = "resouces/" + doc + "/historyList.json"     
            with open(storeHistory) as json_file:
                d = json.load(json_file)
                temp = d
                y = {"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"uploaded", "Performed" :"By You."}
                temp.append(y)

            write_json(d,storeHistory)

            # with open("resouces/" + doc +'/historyList.json') as ef:
            #     d = json.load(ef)
            #     temp = d['emp_details']
            #     # d = json.load(ef)
            #     # d.update({"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"uploaded"})
            #     # ef.seek(0)
            #     temp.append({"name":f_name+"", "date":dateTime[0:10]+"", "time" : dateTime[11:19] +"","action":"uploaded"})
            #     json.dump(d, ef)
                

            return Response({"status": "File Uploaded"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)