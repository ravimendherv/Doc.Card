from rest_framework import serializers

from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from .models import UploardFileModel
from django.http import HttpResponse




class UploadFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UploardFileModel
        fields = ['doc_id','input_file','file_name','timestamp']
        # extra_kwargs = {'mobile_no':{'write_only':True}}
        
class DownloadFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UploardFileModel
        fields = ['doc_id','receiver_doc_id','file_name']

class DeleteFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UploardFileModel
        fields = ['doc_id','file_name']

class DeleterZipFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UploardFileModel
        # receiver_doc_id = serializers.IntegerField()
        fields = ['doc_id','file_name','receiver_doc_id']
        # extra_kwargs = {}