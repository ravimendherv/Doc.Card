from django.apps import AppConfig


class RegistrationApiConfig(AppConfig):
    name = 'registration_api'
