from django.urls import path, include
from .views import UserRegistrationViews, SenderRegistrationViews, ReceicerRegistrationViews, SenderKeyViews, SenderKeyRegistrationProcessViews, SenderRegistrationProcessViews, ReceicerRegistrationProcessViews
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('UserRegistrationViews', UserRegistrationViews,basename="Create")
router.register('SenderRegistration', SenderRegistrationViews)
router.register('SenderKey', SenderKeyViews)
router.register('ReceicerRegistration', ReceicerRegistrationViews)
router.register('SenderRegistrationProcessViews', SenderRegistrationProcessViews)
router.register('SenderKeyRegistrationProcessViews', SenderKeyRegistrationProcessViews)
router.register('ReceicerRegistrationProcessViews', ReceicerRegistrationProcessViews)




# router.register('user_create',user_post)

urlpatterns = [
    path('',include(router.urls)),
    # path('user_create',user_post),

]
