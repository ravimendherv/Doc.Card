from .Google import Create_Service
import base64
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime

class GeneralEmailSender():
    def __init__(self,sub,rec,msg):
        self.subject = sub
        self.receiver = rec
        self.masseage = msg


    def sendingEmail(self):
                    
        CLIENT_SECRET_FILE = 'client_secret.json'
        API_NAME = 'gmail'
        API_VERSION = 'v1'
        SCOPES = ['https://mail.google.com/']


        # print(self.number) 
        # print(self.subject) 
        # print(self.receiver) 
        # print(self.masseage) 
        # print(self.otp)
        # print(self.id)
        # now = datetime.datetime.now()
        # now_plus_5 = now + datetime.timedelta(minutes = 5)
        # time = str(now_plus_5.strftime("%H:%M"))

        service = Create_Service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)

        emailMsg = '<h1 style="color:#00FFFF;"> '+self.subject+'</h1><hr><h2 style="color:#FF00FF;"'+'<h2>Hello Doc.Card User.'+'</h2>'+'<br><h2 style="color: #FFC300 ;">'+str(self.masseage)+' </h2><hr>'
        mimeMessage = MIMEMultipart()
        mimeMessage['to'] = str(self.receiver)
        mimeMessage['subject'] = str(self.subject)
        mimeMessage.attach(MIMEText(emailMsg, 'html'))
        raw_string = base64.urlsafe_b64encode(mimeMessage.as_bytes()).decode()

        message = service.users().messages().send(userId='me', body={'raw': raw_string}).execute()

        return True






# obj = GeneralEmailSender("Doc.Card Feedback process.","ravimendherv@gmail.com","Thank you Ravi Mendhe, for your valueable feedback on feedback. Our support team we take a note of these issus as soon as possible")
# flag = obj.sendingEmail()
# print(flag)
