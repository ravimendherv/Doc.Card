import qrcode
import random
import barcode
from barcode.writer import ImageWriter
from os import getcwd
class CodeGenerator:    
    
    def barcoder(self,data,address):
        bar_code = barcode.Gs1_128(str(data), writer = ImageWriter())
        d = bar_code.save(address + "BarCode")

    def qrcoder(self,data,address):    
        qr_code = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=1,
        )
        qr_code.add_data(data)
        qr_code.make(fit=True)
        qr_img = qr_code.make_image(fill_color="black", back_color="white")
        qr_img.save(address +'QRCode.png')

    def givedata(self):
        return self.data

    def binary_search(self,arr, x):
        low = 0
        high = len(arr) - 1
        mid = 0 
        while low <= high:
            mid = (high + low) // 2
            if arr[mid] < x:
                low = mid + 1
            elif arr[mid] > x:
                high = mid - 1
            else:
                return 1
        return -1

    # if __name__ == '__main__':
    def main(self):
        global data
        global get_list
        flag = 1
        current = getcwd()
        with open(current + "\\registration_api\\Resources\\MainList.txt", "r") as f:
                get_list = f.read()
                get_list = get_list.replace(get_list[0],"",1)
                get_list = get_list.replace(get_list[-1],"",1)
                get_list = get_list.split(',')
                get_list = [int(i) for i in get_list]
        while flag == 1:
            data = random.randint(000000000000,999999999999)
            if len(str(data)) == 12:
                flag = self.binary_search(get_list, data)
                if flag == -1:
                    with open(current + "\\registration_api\\Resources\\MainList.txt", "w") as f:
                        get_list.append(data)
                        get_list.sort()
                        f.write(str(get_list)) 
                    break
            else:
                continue
        return data

    # if __name__ == '__main__':

        
        
        
        # print(data)
        # barcoder(data)
        # qrcoder(data)
        # print("Done")
        # return data 

# obj = CodeGenerator()   
# key = CodeGenerator().givedata
# d = obj.givedata()
# obj.barcoder(d,'123//')
# obj.qrcoder(d,'123//')
# print(d)     
