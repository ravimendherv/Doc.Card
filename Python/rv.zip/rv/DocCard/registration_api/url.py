from django.urls import path, include
from .views import user_post, user_emailsender, userEmailVerificationRegistration, smsVerificationRegistration



urlpatterns = [
    path('user_create/',user_post),
    path('email_to_username/',user_emailsender),
    path('emailVerificationAtRegistaration/',userEmailVerificationRegistration),
    path('smsVerificationAtRegistaration/',smsVerificationRegistration),
]
