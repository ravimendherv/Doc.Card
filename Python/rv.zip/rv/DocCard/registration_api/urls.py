from django.urls import path, include
from .views import UserRegistrationViews, SenderRegistrationViews, ReceicerRegistrationViews, SenderKeyViews, user_post
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('UserRegistrationViews', UserRegistrationViews,basename="Create")
router.register('SenderRegistration', SenderRegistrationViews)
router.register('SenderKey', SenderKeyViews)
router.register('ReceicerRegistration', ReceicerRegistrationViews)
# router.register('user_create',user_post)

urlpatterns = [
    path('',include(router.urls)),
    # path('user_create',user_post),

]
