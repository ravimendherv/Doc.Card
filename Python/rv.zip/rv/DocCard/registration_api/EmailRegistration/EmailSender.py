from .Google import Create_Service
import base64
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class EmailSender():
    def __init__(self,sub,rec,msg,otp):
        self.subject = sub
        self.receiver = rec
        self.masseage = msg
        self.otp = otp

    def sendingEmail(self):
                    
        CLIENT_SECRET_FILE = 'client_secret.json'
        API_NAME = 'gmail'
        API_VERSION = 'v1'
        SCOPES = ['https://mail.google.com/']


        # print(self.number) 
        # print(self.subject) 
        # print(self.receiver) 
        # print(self.masseage) 
        # print(self.otp)
        # print(self.id)

        service = Create_Service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)

        emailMsg = '<h1 style="color:#00FFFF;"> '+self.subject+'</h1><hr><h2 style="color:#FF00FF;"'+'<h2>Hello Doc.Card User.'+'</h2>'+'<br><h2 style="color: #FFC300 ;">'+str(self.masseage)+'&ensp; '+str(self.otp)+'</h2><hr>'
        mimeMessage = MIMEMultipart()
        mimeMessage['to'] = str(self.receiver)
        mimeMessage['subject'] = str(self.subject)
        mimeMessage.attach(MIMEText(emailMsg, 'html'))
        raw_string = base64.urlsafe_b64encode(mimeMessage.as_bytes()).decode()

        message = service.users().messages().send(userId='me', body={'raw': raw_string}).execute()

        return True
    
    # if __name__ == '__main__':
    #     sendingEmail()

