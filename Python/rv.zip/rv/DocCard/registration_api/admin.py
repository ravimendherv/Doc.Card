from django.contrib import admin
from .models import SenderUserRegistrationModel, ReceiverUserRegistrationModel, SenderKeyModel

# Register your models here.

@admin.register(SenderUserRegistrationModel)
class SenderAdmin(admin.ModelAdmin):
    list_display = ['id', 'doc_id', 'f_name', 'l_name', 'email_id', 'mobile_no', 'dob', 'user_type', 'gender']

@admin.register(ReceiverUserRegistrationModel)
class ReceiverAdmin(admin.ModelAdmin):
    list_display = ['id', 'doc_id', 'f_name', 'l_name', 'email_id', 'mobile_no', 'dob', 'user_type', 'gender']

@admin.register(SenderKeyModel)
class SenderKeyAdmin(admin.ModelAdmin):
    list_display = ['id', 'doc_id', 'date', 'month', 'year']