from django.shortcuts import render
from .serializers import UserRegistrationSerializer, SenderKeySerializer, SenderRegistrationSerializer, ReceicerRegistrationSerializer, UserNameSenderSerializer, UserEmailVerificationAtRegistrationSerializer, SmsVerificationAtRegistrationSerializer
from django.contrib.auth.models import User
from .models import SenderUserRegistrationModel, ReceiverUserRegistrationModel, SenderKeyModel
from rest_framework import viewsets
from django.views import View
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from os import chdir,mkdir,getcwd
import shutil
from .Resources.CodeGenerator import CodeGenerator
from django.core import serializers
from django.http import HttpResponse
from .EmailRegistration.EmailSender import EmailSender
import random
from .EmailRegistration.EmailCheck import EmailChecker
import json
from .SmsSenderRegistration.SmsSender import SmsSender
from .SmsSenderRegistration.SMSChecker import SMSChecker


# Create your views here.
global DOC 

@api_view(['POST'])
def user_post(request):
    if request.method == 'POST':
        serializer = UserRegistrationSerializer(data=request.data)

        obj = CodeGenerator()
        d = obj.main()
        doc = str(d)



        request.data.update({"username": doc})

        # Data getting from post  
        # x = request.data
        # print('X==================',x.get('password'))

        if serializer.is_valid():
            serializer.save()
            current = getcwd()
            chdir(current)
            cwd = getcwd()
            chdir(cwd)
            location = str(d)
            mkdir(location)
            obj.barcoder(d,location + '\\')
            obj.qrcoder(d,location + '\\')    
            shutil.move(cwd + '\\' + location, cwd + '\\resouces\\' + location)    

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




@api_view(['POST'])
def user_emailsender(request):
    if request.method == 'POST':
        serializer = UserNameSenderSerializer(data=request.data)

        # print('___________________________',serializer)


        if serializer.is_valid():
            x = request.data
            y = x.get('email')

            try:
                query1 = User.objects.filter(email=y)
            except:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            request.data.update({"username": query1})
            query = serializers.serialize('json', query1)

            # res = json.loads(query)

            # print(res[0]["fields"]["username"])
            


            # print(query1[0])
            returnVal = str(query1[0])
           
            return HttpResponse([json.dumps({"username":returnVal})], status=status.HTTP_201_CREATED)
            # Response(query, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def userEmailVerificationRegistration(request):
    if request.method == 'POST':
        serializer = UserEmailVerificationAtRegistrationSerializer(data=request.data)

        # print('___________________________',serializer)
        if serializer.is_valid():
            x = request.data
            email_id = x.get('email')

            if email_id == "":
                return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_201_CREATED)
            else:
                current = getcwd()
                # print(current)
                chdir(current+"\\registration_api\\EmailRegistration\\")
                # print(getcwd())
                flagChecker = False
                obj = EmailChecker(email_id)       
                flagChecker = obj.checker()
                if flagChecker:
                    flagSender = False
                    number = random.randint(1000,9999)
                    obj = EmailSender("Doc.Card Verification process.",email_id,"Your OTP is",str(number))
                    flagSender = obj.sendingEmail()
                    chdir(current)
                    print(getcwd())
                    if flagSender:
                        print("Msg is been send  "+ str(number))
                        return HttpResponse([json.dumps({"status":"True", "otp":str(number)})], status=status.HTTP_201_CREATED)
                    else:
                        print("Msg not is been send")
                        return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_201_CREATED)
                else:
                    chdir(current)
                    return HttpResponse([json.dumps({"status":"User Already Register"})], status=status.HTTP_201_CREATED)


@api_view(['POST'])
def smsVerificationRegistration(request):
    if request.method == 'POST':
        serializer = SmsVerificationAtRegistrationSerializer(data=request.data)

        # print('___________________________',serializer)
        if serializer.is_valid():
            x = request.data
            phone_No = int(x.get('mobile_no'))

            if phone_No == 0:
                return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_201_CREATED)
            else:
                current = getcwd()
                # print(current)
                chdir(current+"\\registration_api\\SmsSenderRegistration\\")
                # print(getcwd())
                flagChecker = False
                obj = SMSChecker(phone_No)
                flagChecker = obj.checker()
                if flagChecker:
                    flagSender = False
                    number = random.randint(1000,9999)
                    obj = SmsSender("Card User",str(phone_No)," ","doc.card.royal.vision@gmail.com"," ",str(number))
                    flagSender = obj.sendingEmail()
                    chdir(current)
                    # print(getcwd())
                    if flagSender:
                        # print("Msg is been send  "+ str(number))
                        return HttpResponse([json.dumps({"status":"True", "otp":str(number)})], status=status.HTTP_201_CREATED)
                    else:
                        # print("Msg not is been send")
                        return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_201_CREATED)
                else:
                    chdir(current)
                    return HttpResponse([json.dumps({"status":"User Already Register"})], status=status.HTTP_201_CREATED)

class UserRegistrationViews(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    def create(self, request):
        return Response({"ERROR": "POST IS NOT ALLOWED"}, status=status.HTTP_400_BAD_REQUEST)




class SenderRegistrationViews(viewsets.ModelViewSet):
    queryset = SenderUserRegistrationModel.objects.all()
    serializer_class = SenderRegistrationSerializer


    # def list(self, request):
    #     return Response({"ERROR": "NOT ALLOWED"}, status=status.HTTP_400_BAD_REQUEST)

        
    def create(self, request):
        serializer = SenderRegistrationSerializer(data=request.data)

        if serializer.is_valid():
            x = request.data
            email_id = x.get("email_id")

            current = getcwd()
            # print(current)
            chdir(current+"\\registration_api\\EmailRegistration\\")
            # print(getcwd())
            flagChecker = False
            obj = EmailChecker(email_id)       
            flagChecker = obj.adder()
            chdir(current)

            phone_No = int(x.get("mobile_no"))
            current1 = getcwd()
            # print(current)
            chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
            # print(getcwd())
            flagChecker1 = False
            obj1 = SMSChecker(phone_No)
            flagChecker1 = obj1.main()
            chdir(current1)

            if flagChecker and flagChecker1:
                # print("SENDER _____________________________________________________")
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def destroy(self, request, pk=None):
        try:
            serializer = SenderUserRegistrationModel.objects.get(id=pk)
        except SenderUserRegistrationModel.DoesNotExist:
            return Response({"detail": "Not found."}, status=status.HTTP_400_BAD_REQUEST)

        # x = request.data
        # print(x.get("email_id"))
        # print(str(serializer))
        x = request.data
        email_id = x.get("email_id")

        current = getcwd()
        # print(current)
        chdir(current+"\\registration_api\\EmailRegistration\\")
        # print(getcwd())
        flagChecker = False
        obj = EmailChecker(email_id)       
        flagChecker = obj.remover()
        # print(flagChecker)
        chdir(current)

        phone_No = int(x.get("mobile_no"))
        current1 = getcwd()
        # print(current)
        chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
        # print(getcwd())
        flagChecker1 = False
        obj1 = SMSChecker(phone_No)
        flagChecker1 = obj1.main1()
        # print(flagChecker1)
        chdir(current1)
        if flagChecker and flagChecker1:
            serializer.delete()
            return Response({"Message":"User was deleted"}, status=status.HTTP_201_CREATED)
        else:
            # print(flagChecker1)
            # print(flagChecker)
            return Response({"detail": "Not found."}, status=status.HTTP_400_BAD_REQUEST)



    def update(self, request, pk=None):
        return Response({"ERROR": "NOT ALLOWED"}, status=status.HTTP_400_BAD_REQUEST)
    
    def partial_update(self, request, pk=None):
        try:
            sender = SenderUserRegistrationModel.objects.get(id=pk)
        except SenderUserRegistrationModel.DoesNotExist:
            return Response({"ERROR": "Not found."}, status=status.HTTP_400_BAD_REQUEST)

        serializer = SenderRegistrationSerializer(sender, data=request.data, partial=True)

        if "email_id" in request.data or "mobile_no" in request.data or "doc_id" in request.data or "dob" in request.data:
            return Response({"ERROR": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

        if serializer.is_valid():
            serializer.save()
            # print("HEY _____________________")
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



        


            






    

class SenderKeyViews(viewsets.ModelViewSet):
    queryset = SenderKeyModel.objects.all()
    serializer_class = SenderKeySerializer

    def destroy(self, request, pk=None):
        try:
            serializer = SenderKeyModel.objects.get(id=pk)
        except SenderKeyModel.DoesNotExist:
            return Response({"detail": "Not found."}, status=status.HTTP_400_BAD_REQUEST)
        serializer.delete()
        return Response({"Message":"User was deleted"}, status=status.HTTP_201_CREATED)
        # return Response({"detail": "Not found."}, status=status.HTTP_400_BAD_REQUEST)





class ReceicerRegistrationViews(viewsets.ModelViewSet):
    queryset = ReceiverUserRegistrationModel.objects.all()
    serializer_class = ReceicerRegistrationSerializer

    def create(self, request):
        serializer = ReceicerRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            x = request.data
            email_id = x.get("email_id")

            current = getcwd()
            # print(current)
            chdir(current+"\\registration_api\\EmailRegistration\\")
            # print(getcwd())
            flagChecker = False
            obj = EmailChecker(email_id)       
            flagChecker = obj.adder()
            chdir(current)

            phone_No = int(x.get("mobile_no"))
            current1 = getcwd()
            # print(current)
            chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
            # print(getcwd())
            flagChecker1 = False
            obj1 = SMSChecker(phone_No)
            flagChecker1 = obj1.main()
            chdir(current1)

            if flagChecker and flagChecker1:
                # print("SENDER _____________________________________________________")
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def destroy(self, request, pk=None):
        try:
            serializer = ReceiverUserRegistrationModel.objects.get(id=pk)
        except ReceiverUserRegistrationModel.DoesNotExist:
            return Response({"detail": "Not found."}, status=status.HTTP_400_BAD_REQUEST)
        x = request.data
        email_id = x.get("email_id")

        current = getcwd()
        # print(current)
        chdir(current+"\\registration_api\\EmailRegistration\\")
        # print(getcwd())
        flagChecker = False
        obj = EmailChecker(email_id)       
        flagChecker = obj.remover()
        # print(flagChecker)
        chdir(current)

        phone_No = int(x.get("mobile_no"))
        current1 = getcwd()
        # print(current)
        chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
        # print(getcwd())
        flagChecker1 = False
        obj1 = SMSChecker(phone_No)
        flagChecker1 = obj1.main1()
        # print(flagChecker1)
        chdir(current1)
        if flagChecker and flagChecker1:
            serializer.delete()
            return Response({"Message":"User was deleted"}, status=status.HTTP_201_CREATED)
        else:
            # print(flagChecker1)
            # print(flagChecker)
            return Response({"detail": "Not found."}, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, pk=None):
        return Response({"ERROR": "NOT ALLOWED"}, status=status.HTTP_400_BAD_REQUEST)

    def partial_update(self, request, pk=None):
        try:
            receiver = ReceiverUserRegistrationModel.objects.get(id=pk)
        except ReceiverUserRegistrationModel.DoesNotExist:
            return Response({"ERROR": "Not found."}, status=status.HTTP_400_BAD_REQUEST)

        serializer = ReceicerRegistrationSerializer(receiver, data=request.data, partial=True)

        if "email_id" in request.data or "mobile_no" in request.data or "doc_id" in request.data or "dob" in request.data:
            return Response({"ERROR": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

        if serializer.is_valid():
            serializer.save()
            # print("HEY _____________________")
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


