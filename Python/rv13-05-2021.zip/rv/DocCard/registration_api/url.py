from django.urls import path, include
from .views import user_post, user_emailsender, userEmailVerificationRegistration, smsVerificationRegistration, getData, getHistoryList, getNotificationList, forgotPasswordView, contactUsView, getUserType, getIdByUsernameView, getUserProfile, getcard, getNotificationCount, receiveDocumentsendotp, deleteUserView, sendOTPToEmailView



urlpatterns = [
    path('user_create/',user_post),
    path('email_to_username/',user_emailsender),
    path('emailVerificationAtRegistaration/',userEmailVerificationRegistration),
    path('smsVerificationAtRegistaration/',smsVerificationRegistration),
    path('getData/',getData),
    path('api/getHistoryList/',getHistoryList),
    path('api/getNotificationList/',getNotificationList),
    path('api/forgotPasswordView/',forgotPasswordView),
    path('contactUsView/',contactUsView),
    path('getUserType/',getUserType),
    path('getIdByUsernameView/',getIdByUsernameView),
    path('getUserProfile/',getUserProfile),
    path('getcard/',getcard),
    path('getNotificationCount/',getNotificationCount),
    path('receiveDocumentsendotp/',receiveDocumentsendotp),
    path('deleteUserView/',deleteUserView),
    path('sendOTPToEmailView/',sendOTPToEmailView),






    # path('token/', MyTokenObtainPairView.as_view(), name='token_obtain_pair'),


]
