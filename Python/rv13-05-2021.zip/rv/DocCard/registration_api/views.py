from django.shortcuts import render
from .serializers import UserRegistrationSerializer, SenderKeySerializer, SenderRegistrationSerializer, ReceicerRegistrationSerializer, UserNameSenderSerializer, UserEmailVerificationAtRegistrationSerializer, SmsVerificationAtRegistrationSerializer, UserHistorySerializer, ContactUsSerializer, MyTokenObtainPairSerializer, ForgotPasswordSerializer, UserProfileSerializer, UserCardSerializer, SendOTPForDocumentSerializer, DeleteUserSerializer, SendOTPToEmailSerializer
from django.contrib.auth.models import User
from .models import SenderUserRegistrationModel, ReceiverUserRegistrationModel, SenderKeyModel
from rest_framework import viewsets
from django.views import View
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.response import Response
from rest_framework import status
from os import chdir,mkdir,getcwd, remove
import shutil
from .Resources.CodeGenerator import CodeGenerator
from django.core import serializers
from django.http import HttpResponse
from .EmailRegistration.EmailSender import EmailSender
from .EmailRegistration.GeneralEmailSender import GeneralEmailSender
import random
from .EmailRegistration.EmailCheck import EmailChecker
from .CardMaker.CardMaker import CardMaker 
import json
from .SmsSenderRegistration.SmsSender import SmsSender
from .SmsSenderRegistration.SMSChecker import SMSChecker
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import AccessToken, RefreshToken
from datetime import timedelta
import datetime
from rest_framework_simplejwt.views import TokenObtainPairView
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.hashers import make_password
# Create your views here.
# global DOC 


# create user Method

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def getData(request):
    if request.method == 'GET':
        username = request.query_params['username']

        try:
            # print("In to Sender")
            userType = SenderUserRegistrationModel.objects.filter(doc_id = username)
        except SenderUserRegistrationModel.DoesNotExist:
            return Response({"status": "Not Found"}, status=status.HTTP_400_BAD_REQUEST)
        
        with open("resouces/" + str(username) +'/filenameslist.txt','r') as ef1:
                comparedata = ef1.read()
        comparedata.replace(',','')
        comparedata = comparedata.split(',')
        comparedata.pop(0)
        comparedata.pop(-1)

        
        return Response(comparedata, status=status.HTTP_200_OK)


@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def getIdByUsernameView(request):    
    if request.method == 'POST':
        x = request.data
        y = x.get('username')
        username = str(y)
        try:
            query1 = User.objects.filter(username=y)
        except:
            return Response({"status": "Invalid Username"}, status=status.HTTP_400_BAD_REQUEST)

        query = serializers.serialize('json', query1)


        res = json.loads(query)
        # print(res)

        user_id = res[0]["pk"]
        
        # current = getcwd()
        # chdir(current+"\\registration_api\\EmailRegistration\\")
        # flagSender = False
        # number = random.randint(100000,999999)
        # obj = EmailSender("Doc.Card Password Verification process.",email_id,"Your OTP is",str(number))
        # flagSender = obj.sendingEmail()
        # chdir(current)
        # if flagSender:
        return HttpResponse([json.dumps({"id":str(user_id)})], status=status.HTTP_200_OK)
        # else:
                # return HttpResponse([json.dumps({"status":"False", "otp":"0000","id":"NULL"})], status=status.HTTP_200_OK)

               
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)








@api_view(['POST'])
# @authentication_classes([JWTAuthentication])
# @permission_classes([IsAdminUser|IsAuthenticated])
def contactUsView(request):
    if request.method == 'POST':
        serializer = ContactUsSerializer(data=request.data)
        if serializer.is_valid():
            x = request.data
            name = x.get('name')
            # send_Copy = int(x.get('send_Copy'))
            subject = x.get('subject')
            comment = x.get('comment')
            email_id = x.get('email_id')

            dateTime = str(datetime.datetime.now())

            def write_json(d, storeHistory):
                with open(storeHistory,'w') as f:
                    json.dump(d, f, indent=4)
                
            storeHistory = "resouces/contact_Us.json"     
            with open(storeHistory) as json_file:
                d = json.load(json_file)
                temp = d
                y = {"email_id":email_id,"name":name+"","subject": subject, "comment": comment, "date" : dateTime[0:10]+"", "time" : dateTime[11:19] +""}
                temp.append(y)

            write_json(d,storeHistory)

            # if send_Copy == 1:
            #     current = getcwd()
            #     chdir(current+"\\registration_api\\EmailRegistration\\")
            #     obj = GeneralEmailSender("Doc.Card Feedback process.",email_id,"Thank you "+name+ ", for your valueable feedback on "+subject+". Our support team will take a note of these issue as soon as possible")
            #     flag = obj.sendingEmail()
            #     chdir(current)
            #     if flag:
            #         return Response({"status": "email is sended"}, status=status.HTTP_200_OK)
            #     else:
            #         return Response({"status": "email is not sended"}, status=status.HTTP_200_OK)

            return Response({"status": "record is stored"}, status=status.HTTP_200_OK)
        return Response({"status": "record is not stored"}, status=status.HTTP_200_OK)


@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def getHistoryList(request):
    if request.method == 'POST':
        serializer = UserHistorySerializer(data=request.data)
        x = request.data
        username = x.get('username')
        # username = request.query_params['username']
        with open("resouces/" + str(username) +'/historyList.json','r') as ef1:
            comparedata = json.load(ef1)
               
        return Response(comparedata, status=status.HTTP_200_OK)


@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def getNotificationList(request):

    x = request.data
    username = str(x.get('username'))
    rec_int = int(username)

    try:
        receiverQuery = ReceiverUserRegistrationModel.objects.filter(doc_id=rec_int)
    except:
        return Response({"status": "Invalid Receiver id"}, status=status.HTTP_400_BAD_REQUEST)


    if request.method == 'POST':
        serializer = UserHistorySerializer(data=request.data)
        
        # username = request.query_params['username']
        with open("resouces/" + str(username) +'/notificationList.json','r') as ef1:
            comparedata = json.load(ef1)
               
        return Response(comparedata, status=status.HTTP_200_OK)



@api_view(['POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAdminUser])
def forgotPasswordView(request):    
    if request.method == 'POST':
        serializer = UserEmailVerificationAtRegistrationSerializer(data=request.data)
        if serializer.is_valid():

            x = request.data
            y = x.get('email')
            email_id = str(y)
            try:
                query1 = User.objects.filter(email=y)
            except:
                return Response({"status": "Invalid Email id"}, status=status.HTTP_400_BAD_REQUEST)

            query = serializers.serialize('json', query1)


            res = json.loads(query)

            user_id = res[0]["pk"]
           
            current = getcwd()
            chdir(current+"\\registration_api\\EmailRegistration\\")
            flagSender = False
            number = random.randint(100000,999999)
            obj = EmailSender("Doc.Card Password Verification process.",email_id,"Your OTP is",str(number))
            flagSender = obj.sendingEmail()
            chdir(current)
            if flagSender:
                return HttpResponse([json.dumps({"status":"True", "otp":str(number),"id":str(user_id)})], status=status.HTTP_200_OK)
            else:
                return HttpResponse([json.dumps({"status":"False", "otp":"0000","id":"NULL"})], status=status.HTTP_200_OK)

               
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAdminUser])
def user_post(request):
    if request.method == 'POST':
        serializer = UserRegistrationSerializer(data=request.data)

        obj = CodeGenerator()
        d = obj.main()
        doc = str(d)

        print(doc)
        request.data.update({"username": doc})

        # Data getting from post  
        # x = request.data
        # print('X==================',x.get('password'))

        if serializer.is_valid():
            serializer.save()
            current = getcwd()
            chdir(current)
            cwd = getcwd()
            chdir(cwd)
            location = str(d)
            mkdir(location)
            temp = location + "\\output"
            mkdir(temp)
            obj.barcoder(d,location + '\\')
            obj.qrcoder(d,location + '\\')    
            shutil.move(cwd + '\\' + location, cwd + '\\resouces\\' + location)
            chdir(cwd + '\\resouces\\' + location +'\\')
            with open("historyList.json", "w") as f1:
                f1.write("[]")
            
            chdir(current)




            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Give email id take username Method

@api_view(['POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAdminUser])
def user_emailsender(request):
    if request.method == 'POST':
        serializer = UserNameSenderSerializer(data=request.data)

        # For getting the requseted user name use below statement

        # user = request.user

        # print('___________________________',serializer)


        if serializer.is_valid():
            x = request.data
            y = x.get('email')

            try:
                query1 = User.objects.filter(email=y)
            except:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            query = serializers.serialize('json', query1)

            # res = json.loads(query)
            # print(res[0]["fields"]["username"])
            # print(query1[0])
            returnVal = str(query1[0])
        
           
            return Response({"username":returnVal}, status=status.HTTP_200_OK)
            # Response(query, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





@api_view(['POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAdminUser])
def getUserType(request):
    if request.method == 'POST':
        serializer = UserNameSenderSerializer(data=request.data)

        # For getting the requseted user name use below statement

        # user = request.user

        # print('___________________________',serializer)


        if serializer.is_valid():
            x = request.data
            y = int(x.get('username'))

            try:
                query1 = User.objects.filter(username=y)
            except:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            try:
                print("In to Sender")
                userType = SenderUserRegistrationModel.objects.filter(doc_id = y)
                if userType:
                    flag = 0
                print(flag)
            except:
                pass

            try:
                print("In to Receiver")
                userType1 = ReceiverUserRegistrationModel.objects.filter(doc_id = y)
                if userType1:
                    flag = 1
                print(flag)
            except:
                pass
           
            return Response({"username":str(y),"user_type":str(flag)}, status=status.HTTP_200_OK)
            # Response(query, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Email verification Method

@api_view(['POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAdminUser])
def userEmailVerificationRegistration(request):
    if request.method == 'POST':
        serializer = UserEmailVerificationAtRegistrationSerializer(data=request.data)

        # print('___________________________',serializer)
        if serializer.is_valid():
            x = request.data
            email_id = x.get('email')

            if email_id == "":
                return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_200_OK)
            else:
                current = getcwd()
                # print(current,"_______________________")
                chdir(current+"\\registration_api\\EmailRegistration\\")
                # print(getcwd())
                flagChecker = False
                obj = EmailChecker(email_id)       
                flagChecker = obj.checker()
                if flagChecker:
                    flagSender = False
                    number = random.randint(1000,9999)
                    obj = EmailSender("Doc.Card Verification process.",email_id,"Your OTP is",str(number))
                    flagSender = obj.sendingEmail()
                    chdir(current)
                    print(getcwd())
                    if flagSender:
                        print("Msg is been send  "+ str(number))
                        return HttpResponse([json.dumps({"status":"True", "otp":str(number)})], status=status.HTTP_200_OK)
                    else:
                        print("Msg not is been send")
                        return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_200_OK)
                else:
                    chdir(current)
                    return HttpResponse([json.dumps({"status":"User Already Register"})], status=status.HTTP_200_OK)


# phone no. verification Method222

@api_view(['POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAdminUser])
def smsVerificationRegistration(request):
    if request.method == 'POST':
        serializer = SmsVerificationAtRegistrationSerializer(data=request.data)

        # print('___________________________',serializer)
        if serializer.is_valid():
            x = request.data
            phone_No = int(x.get('mobile_no'))

            if phone_No == 0:
                return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_200_OK)
            else:
                current = getcwd()
                # print(current)
                chdir(current+"\\registration_api\\SmsSenderRegistration\\")
                # print(getcwd())
                flagChecker = False
                obj = SMSChecker(phone_No)
                flagChecker = obj.checker()
                if flagChecker:
                    flagSender = False
                    number = random.randint(1000,9999)
                    obj = SmsSender("Card User",str(phone_No)," ","doc.card.royal.vision@gmail.com"," ",str(number))
                    flagSender = obj.sendingEmail()
                    chdir(current)
                    # print(getcwd())
                    if flagSender:
                        # print("Msg is been send  "+ str(number))
                        return HttpResponse([json.dumps({"status":"True", "otp":str(number)})], status=status.HTTP_200_OK)
                    else:
                        # print("Msg not is been send")
                        return HttpResponse([json.dumps({"status":"False", "otp":"0000"})], status=status.HTTP_200_OK)
                else:
                    chdir(current)
                    return HttpResponse([json.dumps({"status":"User Already Register"})], status=status.HTTP_200_OK)
        else:
            return HttpResponse([json.dumps({"status":"User Already Register"})], status=status.HTTP_200_OK)    

# By using UserRegistrationViews class you can update f_name, l_name, email_id, password
# just this class having JWT Token Auth. 

class UserRegistrationViews(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    authentication_classes = [JWTAuthentication,TokenAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]        
    
    def create(self, request):
        return Response({"status": "Post is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        x = request.data
        user = x.get("username")
        current = getcwd()
        path = (current + '\\resouces\\' + str(user))
        shutil.rmtree(path)
        return Response({"status": "User is Delete"}, status=status.HTTP_200_OK)

    def partial_update(self, request, pk=None):


        if "password" in request.data:
            x = request.data
            try:
                new_password = x.get("password")
            except:
                pass
                # return Response({"status": "This is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
        elif "email" in request.data:
            sent = User.objects.get(id=pk)
            serializer = UserRegistrationSerializer(sent, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                # print("HEY _____________________")
                return Response(serializer.data, status=status.HTTP_200_OK)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"status": "This is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

        # password = make_password(new_password)
        self.object = self.get_object()
        self.object.set_password(x.get("password"))
        self.object.save()
        return Response({"status": "Password is Reset Successfully"}, status=status.HTTP_200_OK)






    # def get(self):
    #     authentication_classes= [TokenAuthentication]
    #     permission_classes= [IsAdminUser]
    #     return Response(serializer.data, status=status.HTTP_200_OK)


# Class SenderRegistrationProcessViews is use for only registration of Sender User  


class SenderRegistrationProcessViews(viewsets.ModelViewSet):
    queryset = SenderUserRegistrationModel.objects.all()
    serializer_class = SenderRegistrationSerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAdminUser]


    def create(self, request):
        serializer = SenderRegistrationSerializer(data=request.data)
        d = request.data
        print(d)
        

        if serializer.is_valid():
            x = request.data
            email_id = x.get("email_id")
            doc = x.get("doc_id")
            name = str(x.get("f_name")) + " " + str(x.get("l_name"))

            current = getcwd()
            # print(current)
            chdir(current+"\\registration_api\\EmailRegistration\\")
            # print(getcwd())
            flagChecker = False
            obj = EmailChecker(email_id)       
            flagChecker = obj.adder()
            chdir(current)

            phone_No = int(x.get("mobile_no"))
            current1 = getcwd()
            # print(current)
            chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
            # print(getcwd())
            flagChecker1 = False
            obj1 = SMSChecker(phone_No)
            flagChecker1 = obj1.main()
            chdir(current1)

            chdir(current1 + '\\resouces\\' + str(doc) + '\\')
            with open("filenameslist.txt", "w") as f:
                f.write(",")
            chdir(current1)
            if flagChecker and flagChecker1:
                # print("SENDER _____________________________________________________")
                serializer.save()
                current = getcwd()
                chdir(current+"\\registration_api\\EmailRegistration\\")
                obj = GeneralEmailSender("Doc.Card Sender User Successfully Register.",email_id,"Thank you "+name+ ", for registation on our Doc.Card Portal, We Welcome You")
                flag = obj.sendingEmail()
                chdir(current)
                current2 = getcwd()
                chdir(current2+"\\registration_api\\CardMaker\\")
                o = CardMaker(str(doc),name,current2 + '\\resouces\\' + str(doc) + '\\',current2+"\\registration_api\\CardMaker\\")
                o.cardgenrator()
                chdir(current2)
                return Response({"status":"Step 1 Complete"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        return Response({"status": "Delete is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        return Response({"status": "Get is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, pk=None):
        return Response({"status": "Update is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
    
    def partial_update(self, request, pk=None):
        return Response({"status": "Patch is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def list(self, request):
        return Response({"status": "Get is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)


# Class SenderRegistrationViews is use for update, delete operation for Sender User 

class SenderRegistrationViews(viewsets.ModelViewSet):
    queryset = SenderUserRegistrationModel.objects.all()
    serializer_class = SenderRegistrationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]
    # AccessToken.lifetime = timedelta(seconds=120)



    # def list(self, request):
    #     return Response({"ERROR": "NOT ALLOWED"}, status=status.HTTP_400_BAD_REQUEST)

        
    def create(self, request):
        return Response({"status": "Post is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)


        # serializer = SenderRegistrationSerializer(data=request.data)
        

        # if serializer.is_valid():
        #     x = request.data
        #     email_id = x.get("email_id")

        #     current = getcwd()
        #     # print(current)
        #     chdir(current+"\\registration_api\\EmailRegistration\\")
        #     # print(getcwd())
        #     flagChecker = False
        #     obj = EmailChecker(email_id)       
        #     flagChecker = obj.adder()
        #     chdir(current)

        #     phone_No = int(x.get("mobile_no"))
        #     current1 = getcwd()
        #     # print(current)
        #     chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
        #     # print(getcwd())
        #     flagChecker1 = False
        #     obj1 = SMSChecker(phone_No)
        #     flagChecker1 = obj1.main()
        #     chdir(current1)

        #     if flagChecker and flagChecker1:
        #         # print("SENDER _____________________________________________________")
        #         serializer.save()
        #         return Response({"status":"Step 1 Complete"}, status=status.HTTP_200_OK)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def destroy(self, request, pk=None):
        try:
            serializer = SenderUserRegistrationModel.objects.get(id=pk)
        except SenderUserRegistrationModel.DoesNotExist:
            return Response({"status": "Not Found"}, status=status.HTTP_400_BAD_REQUEST)

        # x = request.data
        # print(str(serializer))
        x = request.data
        email_id = x.get("email_id")
        print(x.get("email_id"),"_________________________")

        current = getcwd()
        print(current)
        chdir(current+"\\registration_api\\EmailRegistration\\")
        print(getcwd())
        flagChecker = False
        obj = EmailChecker(email_id)       
        flagChecker = obj.remover()
        print(flagChecker)
        chdir(current)

        phone_No = int(x.get("mobile_no"))
        current1 = getcwd()
        # print(current)
        chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
        print(getcwd())
        flagChecker1 = False
        obj1 = SMSChecker(phone_No)
        flagChecker1 = obj1.main1()
        print(flagChecker1)
        chdir(current1)
        if flagChecker and flagChecker1:
            serializer.delete()
            return Response({"status":"User is Deleted"}, status=status.HTTP_200_OK)
        else:
            # print(flagChecker1)
            # print(flagChecker)
            return Response({"status": "Not found."}, status=status.HTTP_400_BAD_REQUEST)



    def update(self, request, pk=None):
        return Response({"status": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
    
    def partial_update(self, request, pk=None):
        try:
            sender = SenderUserRegistrationModel.objects.get(id=pk)
        except SenderUserRegistrationModel.DoesNotExist:
            return Response({"status": "Not Found."}, status=status.HTTP_400_BAD_REQUEST)

        serializer = SenderRegistrationSerializer(sender, data=request.data, partial=True)

        if "f_name" in request.data or "l_name" in request.data or "doc_id" in request.data or "dob" in request.data or "user_type" in request.data:
            # print("HEYt _____________________")
            return Response({"status": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
        
        # sender = SenderUserRegistrationModel.objects.get(id=pk)
        # serializer = SenderRegistrationSerializer(sender, data=request.data, partial=True)

        if serializer.is_valid():
            if "email_id" in request.data:
                x = request.data
                email_id = x.get("email_id")
                current = getcwd()
                # print(current)
                chdir(current+"\\registration_api\\EmailRegistration\\")
                # print(getcwd())
                flagChecker = False
                obj = EmailChecker(email_id)       
                flagChecker = obj.adder()
                chdir(current)
                serializer.save()
                # print("HEY _____________________")
                return Response(serializer.data, status=status.HTTP_200_OK)
            elif "mobile_no" in request.data:
                x = request.data
                phone_No = int(x.get("mobile_no"))
                current1 = getcwd()
                # print(current)
                chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
                # print(getcwd())
                flagChecker1 = False
                obj1 = SMSChecker(phone_No)
                flagChecker1 = obj1.main()
                chdir(current1)
                serializer.save()
                # print("HEY _____________________")
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                # request.data
                # print("HEY _____________________"+ str(request.data))
                return Response({"status": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# Class SenderKeyRegistrationProcessViews is use for only registration of Sender User  


class SenderKeyRegistrationProcessViews(viewsets.ModelViewSet):
    queryset = SenderKeyModel.objects.all()
    serializer_class = SenderKeySerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAdminUser]
    # AccessToken.lifetime = timedelta(seconds=60)


    def create(self, request):
        serializer = SenderKeySerializer(data=request.data)
        if serializer.is_valid():
            # authentication_classes= [TokenAuthentication]
            # permission_classes= [IsAdminUser]
            x = request.data
            doc = x.get("doc_id")
            # d = int(x.get("date"))
            # dd = ""
            # m = int(x.get("month"))
            # mm = ""
            # y = int(x.get("year"))
            # if d < 10:
            #     dd = "0"+str(d)
            # else:
            #     dd = str(d)


            # if m < 10:
            #     mm = "0"+str(m)
            # else:
            #     mm = str(m)

            # request.data.update({"date": dd})
            # request.data.update({"month": mm})
            # request.data.update({"year": str(y)})

            # serializer.save()
       
            return Response({"status":"Sender Created"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        return Response({"status": "Delete is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        return Response({"status": "Get is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
    
    def update(self, request, pk=None):
        return Response({"status": "Update is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
    
    def partial_update(self, request, pk=None):
        return Response({"status": "Patch is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def list(self, request):
        return Response({"status": "Get is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
        


            





# Class SenderKeyViews is use for update, delete operation for Sender User 

class SenderKeyViews(viewsets.ModelViewSet):
    queryset = SenderKeyModel.objects.all()
    serializer_class = SenderKeySerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]


    # def list(self, request):
    #     username = request.user.username
    #     return Response({"status": ""+str(username)}, status=status.HTTP_200_OK)

    def create(self, request):
        return Response({"status": "Post is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)


    # def create(self, request):
    #     serializer = SenderKeySerializer(data=request.data)
        

    #     if serializer.is_valid():
    #         authentication_classes= [TokenAuthentication]
    #         permission_classes= [IsAdminUser]
    #         x = request.data
    #         doc = x.get("doc_id")
    #         serializer.save()
    #         return Response({"status":"Sender Created"}, status=status.HTTP_200_OK)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        try:
            serializer = SenderKeyModel.objects.get(id=pk)
        except SenderKeyModel.DoesNotExist:
            return Response({"status": "Not Found."}, status=status.HTTP_400_BAD_REQUEST)
        serializer.delete()
        return Response({"status":"User is Deleted"}, status=status.HTTP_200_OK)
        # return Response({"detail": "Not found."}, status=status.HTTP_400_BAD_REQUEST)


# Class ReceicerRegistrationProcess is use for only registration of Sender User  


class ReceicerRegistrationProcessViews(viewsets.ModelViewSet):
    queryset = ReceiverUserRegistrationModel.objects.all()
    serializer_class = ReceicerRegistrationSerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAdminUser]

    def create(self, request):
        serializer = ReceicerRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            x = request.data
            email_id = x.get("email_id")
            doc = x.get("doc_id")
            name = str(x.get("f_name")) + " " + str(x.get("l_name"))


            current = getcwd()
            # print(current)
            chdir(current+"\\registration_api\\EmailRegistration\\")
            # print(getcwd())
            flagChecker = False
            obj = EmailChecker(email_id)       
            flagChecker = obj.adder()
            chdir(current)

            phone_No = int(x.get("mobile_no"))
            current1 = getcwd()
            # print(current)
            chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
            # print(getcwd())
            flagChecker1 = False
            obj1 = SMSChecker(phone_No)
            flagChecker1 = obj1.main()
            chdir(current1)

            chdir(current1 + '\\resouces\\' + str(doc) + '\\')
            remove("BarCode.png")
            remove("QRCode.png")
            with open("notificationList.json", "w") as f1:
                f1.write("[]")
            chdir(current1)


            if flagChecker and flagChecker1:
                # print("SENDER _____________________________________________________")
                serializer.save()
                current = getcwd()
                chdir(current+"\\registration_api\\EmailRegistration\\")
                obj = GeneralEmailSender("Doc.Card Receiver User Successfully Register.",email_id,"Thank you "+name+ ", for registation on our Doc.Card Portal, We Welcome You")
                flag = obj.sendingEmail()
                chdir(current)
                return Response({"status":"Receiver Create"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        return Response({"status": "Delete is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        return Response({"status": "Get is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, pk=None):
        return Response({"status": "Update is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)
    
    def partial_update(self, request, pk=None):
        return Response({"status": "Patch is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def list(self, request):
        return Response({"status": "Get is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)


# Class SenderKeyViews is use for update, delete operation for Sender User 

class ReceicerRegistrationViews(viewsets.ModelViewSet):
    queryset = ReceiverUserRegistrationModel.objects.all()
    serializer_class = ReceicerRegistrationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUser|IsAuthenticated]

    def create(self, request):
        return Response({"status": "Post is Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)


    # def create(self, request):
    #     serializer = ReceicerRegistrationSerializer(data=request.data)
    #     if serializer.is_valid():
    #         x = request.data
    #         email_id = x.get("email_id")

    #         current = getcwd()
    #         # print(current)
    #         chdir(current+"\\registration_api\\EmailRegistration\\")
    #         # print(getcwd())
    #         flagChecker = False
    #         obj = EmailChecker(email_id)       
    #         flagChecker = obj.adder()
    #         chdir(current)

    #         phone_No = int(x.get("mobile_no"))
    #         current1 = getcwd()
    #         # print(current)
    #         chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
    #         # print(getcwd())
    #         flagChecker1 = False
    #         obj1 = SMSChecker(phone_No)
    #         flagChecker1 = obj1.main()
    #         chdir(current1)

    #         if flagChecker and flagChecker1:
    #             # print("SENDER _____________________________________________________")
    #             serializer.save()
    #             return Response({"status":"Receiver Create"}, status=status.HTTP_200_OK)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def destroy(self, request, pk=None):
        try:
            serializer = ReceiverUserRegistrationModel.objects.get(id=pk)
        except ReceiverUserRegistrationModel.DoesNotExist:
            return Response({"status": "Not Found"}, status=status.HTTP_400_BAD_REQUEST)
        x = request.data
        email_id = x.get("email_id")

        current = getcwd()
        # print(current)
        chdir(current+"\\registration_api\\EmailRegistration\\")
        # print(getcwd())
        flagChecker = False
        obj = EmailChecker(email_id)       
        flagChecker = obj.remover()
        # print(flagChecker)
        chdir(current)

        phone_No = int(x.get("mobile_no"))
        current1 = getcwd()
        # print(current)
        chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
        # print(getcwd())
        flagChecker1 = False
        obj1 = SMSChecker(phone_No)
        flagChecker1 = obj1.main1()
        # print(flagChecker1)
        chdir(current1)
        if flagChecker and flagChecker1:
            serializer.delete()
            return Response({"status":"User is Deleted"}, status=status.HTTP_200_OK)
        else:
            # print(flagChecker1)
            # print(flagChecker)
            return Response({"status": "Not Found"}, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, pk=None):
        return Response({"status": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

    def partial_update(self, request, pk=None):
        try:
            receiver = ReceiverUserRegistrationModel.objects.get(id=pk)
        except ReceiverUserRegistrationModel.DoesNotExist:
            return Response({"status": "Not Found"}, status=status.HTTP_400_BAD_REQUEST)

        serializer = ReceicerRegistrationSerializer(receiver, data=request.data, partial=True)

        if "f_name" in request.data or "l_name" in request.data or "doc_id" in request.data or "dob" in request.data or "user_type" in request.data:
            return Response({"status": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

        if serializer.is_valid():
            if "email_id" in request.data:
                x = request.data
                email_id = x.get("email_id")
                current = getcwd()
                # print(current)
                chdir(current+"\\registration_api\\EmailRegistration\\")
                # print(getcwd())
                flagChecker = False
                obj = EmailChecker(email_id)       
                flagChecker = obj.adder()
                chdir(current)
                serializer.save()
                # print("HEY _____________________")
                return Response(serializer.data, status=status.HTTP_200_OK)
            elif "mobile_no" in request.data:
                phone_No = int(x.get("mobile_no"))
                current1 = getcwd()
                # print(current)
                chdir(current1+"\\registration_api\\SmsSenderRegistration\\")
                # print(getcwd())
                flagChecker1 = False
                obj1 = SMSChecker(phone_No)
                flagChecker1 = obj1.main()
                chdir(current1)
                serializer.save()
                # print("HEY _____________________")
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"status": "Not Allowed"}, status=status.HTTP_400_BAD_REQUEST)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer
    AccessToken.lifetime = timedelta(minutes=60)

    



@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def getUserProfile(request):
    if request.method == 'GET':
        serializer = UserProfileSerializer(data=request.data)
        if serializer.is_valid():
            x = request.data
            f_name = request.user.first_name
            l_name = request.user.last_name
            # username = request.user.username
            username = request.user.username
            email = request.user.email   

            user_type = ""
            mobile_no = ""
            dob = ""
            user_id = ""


            try:
                # print("In to Sender")
                userType = SenderUserRegistrationModel.objects.filter(doc_id = username)
                if userType:
                    user_type = "Sender"
                    user0 = serializers.serialize('json', userType)
                    res = json.loads(user0)
                    mobile_no = str(res[0]['fields']['mobile_no'])
                    dob = str(res[0]['fields']['dob'])
                    user_id = str(res[0]["pk"])


            # user_id = res[0]["pk"]
                # print(user_type)
            except:
                pass

            try:
                # print("In to Receiver")
                userType1 = ReceiverUserRegistrationModel.objects.filter(doc_id = username)
                if userType1:
                    user_type = "Receiver"
                    user1 = serializers.serialize('json', userType1)
                    res = json.loads(user1)
                    mobile_no = str(res[0]['fields']['mobile_no'])
                    dob = str(res[0]['fields']['dob'])
                    user_id = str(res[0]["pk"])

                # print(user_type)
            except:
                pass



            return Response({"username":str(username), "first_name":str(f_name), "last_name":str(l_name), "email":str(email), "moblie_no":str(mobile_no), "date_of_brith":str(dob), "user_type":str(user_type), "id":str(user_id)}, status=status.HTTP_200_OK)
            # Response(query, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def getcard(request):
    if request.method == 'POST':
        # print("Hello")
        serializer = UserCardSerializer(data=request.data)
        # print("Hello")
        x = request.data
        username = x.get("doc_id")
        # if serializer.is_valid():
            # f_name = request.user.first_name
            # l_name = request.user.last_name
        # print("Hello")

        front = ""
        back = ""
        try:
            # print("In to Sender")
            userType = SenderUserRegistrationModel.objects.filter(doc_id = username)
            if userType:
                # user_type = "Sender"
                # user0 = serializers.serialize('json', userType)
                # res = json.loads(user0)
                # mobile_no = str(res[0]['fields']['mobile_no'])
                # dob = str(res[0]['fields']['dob'])
                fs = FileSystemStorage()
        # zip_file = open(location, 'rb')
                front_cardImage = fs.open(str(username) +"/CardFrontSide.png")
                back_cardImage = fs.open(str(username) +"/CardBackSide.png")
                front = fs.url(front_cardImage)
                back = fs.url(back_cardImage)
                del front_cardImage
                del back_cardImage
                # del zip_file
                return Response({"front_side": str(front), "back_side": str(back)}, status=status.HTTP_200_OK)



        # user_id = res[0]["pk"]
            # print(user_type)
        except:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
            # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def getNotificationCount(request):

    x = request.data
    username = str(x.get('doc_id'))
    rec_int = int(username)

    try:
        receiverQuery = ReceiverUserRegistrationModel.objects.filter(doc_id=rec_int)
    except:
        return Response({"status": "Invalid Receiver id"}, status=status.HTTP_400_BAD_REQUEST)


    if request.method == 'POST':
        serializer = UserHistorySerializer(data=request.data)
        
        # username = request.query_params['username']
        with open("resouces/" + str(username) +'/notificationList.json','r') as ef1:
            comparedata = json.load(ef1)
               
        return Response({"count":str(len(comparedata))}, status=status.HTTP_200_OK)


@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def receiveDocumentsendotp(request):
    if request.method == 'POST':
        # print("Hello")
        # serializer = UserCardSerializer(data=request.data)

        receiver_name = str(request.user.first_name)+ " " + (request.user.last_name)
        # print("Hello")
        y = request.data
        username = y.get("doc_id")
        data = y.get("f_name")
        flag = int(y.get("gender"))
        print("user id "+str(username))
        print("data "+str(data))
        print("flag "+str(flag))

        email_id = ""
        mobile_no = ""
        name = ""
# {
#     "doc_id":"698275697749",
#     "f_name":"Pan,ravi,Raj",
#     "gender":"1"

# }

        try:
            # serializer = SenderUserRegistrationModel.objects.get(doc_id=username)
            userType = SenderUserRegistrationModel.objects.filter(doc_id = username)
            if userType:
                user_type = "Sender"
                user0 = serializers.serialize('json', userType)
                res = json.loads(user0)
                mobile_no = str(res[0]['fields']['mobile_no'])
                print(mobile_no)
                email_id = str(res[0]['fields']['email_id'])
                print(email_id)
                name = str(res[0]['fields']['f_name']) + ' ' + str(res[0]['fields']['l_name'])


                # dob = str(res[0]['fields']['dob'])
        except SenderUserRegistrationModel.DoesNotExist:
            return Response({"status": "Not Found"}, status=status.HTTP_400_BAD_REQUEST)

        # x = request.data
        # print(str(serializer))
        # x = request.data
        # email_id = x.get("email_id")
        print(email_id + "_________________________")
        # phone_No = int(x.get("mobile_no"))
        print(mobile_no + "_________________________")
        # smsData = str(name)+ "The Receiver "+ str(receiver_name)

        if flag == 1:
            current = getcwd()
                # print(current)
            chdir(current+"\\registration_api\\SmsSenderRegistration\\")
            number = random.randint(1000,9999)
            # obj = SmsSender(name,str(mobile_no)," ","doc.card.royal.vision@gmail.com"," ",str(number))
            obj = SmsSender(name,str(mobile_no)," ","doc.card.royal.vision@gmail.com",str(data),str(number))

            flagSender = obj.sendingEmail()
            chdir(current)

            if flagSender:
                return Response({"otp":str(number)}, status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        elif flag == 0:
            current = getcwd()
                # print(current,"_______________________")
            chdir(current+"\\registration_api\\EmailRegistration\\")
            number = random.randint(1000,9999)
            obj = EmailSender("Doc.Card Verification process During Send Document.",email_id," The Receiver "+ receiver_name + " As requested for "+ data +" Documents So, for that Your OTP is",str(number))
            flagSender = obj.sendingEmail()
            chdir(current)

            if flagSender:
                return Response({"otp":str(number)}, status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    
@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def deleteUserView(request):
    if request.method == 'POST':
        serializer = DeleteUserSerializer(data=request.data)
        # if serializer.is_valid():
        x = request.data
        name = x.get('name')
        # send_Copy = int(x.get('send_Copy'))
        username = x.get('send_Copy')
        comment = x.get('comment')
        email_id = x.get('email_id')

        dateTime = str(datetime.datetime.now())

        def write_json(d, storeHistory):
            with open(storeHistory,'w') as f:
                json.dump(d, f, indent=4)
            
        storeHistory = "resouces/account_delete.json"     
        with open(storeHistory) as json_file:
            d = json.load(json_file)
            temp = d
            y = {"username": username,"email_id":email_id,"name":name+"","comment": comment, "date" : dateTime[0:10]+"", "time" : dateTime[11:19] +""}
            temp.append(y)

        write_json(d,storeHistory)

        # current = getcwd()
        # chdir(current+"\\registration_api\\EmailRegistration\\")
        # flagSender = False
        # number = random.randint(1000,9999)
        # obj = EmailSender("Doc.Card Verification process.",email_id,"<h2> Hello "+ name + " </h2> Your Doc Card account as send the request for delete the account. our team will delete the account with in 48 hours for verification process, <br> <br>  Your OTP is",str(number))
        # flagSender = obj.sendingEmail()
        # chdir(current)
        # if flagSender:
        #     return Response({"otp": str(number)}, status=status.HTTP_200_OK)
        # else:
        #     return Response({"status": "Email is not found"}, status=status.HTTP_400_BAD_REQUEST)
    
        return Response({"status": "Your request has forwarded successfully, within 48 hours your account will be get delete."}, status=status.HTTP_200_OK)
    return Response({"status": "record is not stored"}, status=status.HTTP_400_BAD_REQUEST)


    
@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAdminUser|IsAuthenticated])
def sendOTPToEmailView(request):
    if request.method == 'POST':
        serializer = SendOTPToEmailSerializer(data=request.data)
        # if serializer.is_valid():
        x = request.data
        name = x.get('name')
        # send_Copy = int(x.get('send_Copy'))
        # username = x.get('send_Copy')
        subject = x.get('subject')
        email_id = x.get('email_id')

        # dateTime = str(datetime.datetime.now())

        # def write_json(d, storeHistory):
        #     with open(storeHistory,'w') as f:
        #         json.dump(d, f, indent=4)
            
        # storeHistory = "resouces/account_delete.json"     
        # with open(storeHistory) as json_file:
        #     d = json.load(json_file)
        #     temp = d
        #     y = {"username": username,"email_id":email_id,"name":name+"","comment": comment, "date" : dateTime[0:10]+"", "time" : dateTime[11:19] +""}
        #     temp.append(y)

        # write_json(d,storeHistory)

        current = getcwd()
        chdir(current+"\\registration_api\\EmailRegistration\\")
        flagSender = False
        number = random.randint(1000,9999)
        obj = EmailSender("Doc.Card Verification process.",email_id,"<h2> Hello "+ name + " </h2> Your Doc Card account as send the request for "+ subject +"<br> <br>  Your OTP is",str(number))
        flagSender = obj.sendingEmail()
        chdir(current)
        if flagSender:
            return Response({"otp": str(number)}, status=status.HTTP_200_OK)
        else:
            return Response({"status": "Email is not found"}, status=status.HTTP_400_BAD_REQUEST)
    
        return Response({"status": "record is stored"}, status=status.HTTP_400_BAD_REQUEST)
    return Response({"status": "record is not stored"}, status=status.HTTP_400_BAD_REQUEST)

