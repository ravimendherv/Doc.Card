# # def wirteList(mainList):
# #     print(str(mainList))
# #     with open("MainList.txt", "w") as f:
# #         mainList.sort()
# #         print(mainList)
# #         f.write(str(mainList))
# # def readList():
# #     with open("MainList.txt", "r") as f:
# #         readedList = f.read()
# #     return readedList

# # def binary_search(arr, x):
# #     low = 0
# #     high = len(arr) - 1
# #     mid = 0 
# #     while low <= high:
# #         mid = (high + low) // 2
# #         if arr[mid] < x:
# #             low = mid + 1
# #         elif arr[mid] > x:
# #             high = mid - 1
# #         else:
# #             return 1
# #     return -1
 
 
# # # Test array
# # arr = [0,2,1]
# # # x = 10
 
# # # # # Function call
# # # result = binary_search(arr, x)
 
# # # if result != -1:
# # #     print("Element is present at index", str(result))
# # # else:
# # #     print("Element is not present in array")

# # wirteList(arr)



# str = "ab1cd1ef"
# Index = -1
# print(str.replace(str[Index],"",1))

# import random
# import barcode
# from barcode.writer import ImageWriter

# def barcoder(data):
#         # code_39 = barcode.get_barcode_class('code39')
#         # bar_code = code_39(str(data), writer = ImageWriter())
#         bar_code = barcode.Gs1_128(str(data), writer = ImageWriter())
#         d = bar_code.save("BarCode")

# data = random.randint(000000000000,999999999999)
# print(data)
# barcoder(data)


# data = 123456781231
# print(len(str(data)))
# data = data + 1
# print(data)