import qrcode
import random
import barcode
from barcode.writer import ImageWriter
class EmailChecker:
    def __init__(self,email_id ):
        global data
        data = email_id

    
    def main(self):        
        global get_list
        flag = 1
        with open("EmailList.txt", "r") as f:
                get_list = f.read()
                # print(get_list)
                # get_list = get_list.replace(get_list[0],"")
                # get_list = get_list.replace(get_list[-1],"")
                get_list = get_list.split(',')
                # print(get_list)
                # get_list = [i for i in get_list]

        # print(get_list)
        # print(type(get_list))
        if data not in get_list:
            flag = -1
        else:
            flag = 2

        if flag == -1:
            with open("EmailList.txt", "a") as f:
                # get_list.append(data)
                # print(get_list
                # print(get_list)
                f.write(data + ",") 
                return True
        else:
            return False
    # print(data)
    # print("Done")

obj = EmailChecker("abcr@gmail.com")       
print(obj.main()) 