from cryptography.fernet import Fernet
import base64

id = '123456789123'
date = '29'
month = '03'
year = '2000'


fkey =base64.b64encode((id+id[::-1]+date+month+year).encode('utf-8'))
# fkey = Fernet.generate_key()

cipher = Fernet(fkey)

filename = '2.pdf'

with open(filename,'rb')as f:
    e_file = f.read()

encrypted_file = cipher.encrypt(e_file)

with open(filename + ".rv",'wb') as ef:
    ef.write(encrypted_file)