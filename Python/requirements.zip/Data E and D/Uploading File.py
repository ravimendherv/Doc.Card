from docx2pdf import convert
from PIL import Image
from fpdf import FPDF 
import win32com.client
from cryptography.fernet import Fernet
import base64
import os


class PDF_Converter:


    def wordToPDF(self,path,name,):
        cwd = os.getcwd()
        convert(name+".docx", cwd+"//"+name+".pdf")
        file_size = os.path.getsize(cwd+"//"+name+".pdf")
        print(str(file_size//1000) + 'KB')
        if (file_size//1000) <= 225:
            self.makeEncrypt(name,name+".pdf")
            os.remove(name+".pdf") 
        else:
            print("ERROR")

            

    def pptToPDF(self,path, name, formatType = 32):
        cwd = os.getcwd()
        ppt = win32com.client.DispatchEx("Powerpoint.Application")
        ppt.Visible = 1
        op = ppt.Presentations.Open(cwd+'//'+path)
        op.SaveAs(cwd+'//'+name+'.pdf', formatType)
        op.Close()
        ppt.Quit()
        file_size = os.path.getsize(cwd+"//"+name+".pdf")
        print(str(file_size//1000) + 'KB')
        if (file_size//1000) <= 225:
            self.makeEncrypt(name,name+".pdf")
            os.remove(name+".pdf") 
        else:
            print("ERROR")

    def imageToPDF(self, path, name):
        ImgFile = Image.open(path)
        if ImgFile.mode == "RGBA":
            ImgFile = ImgFile.convert("RGB")
        ImgFile.save(name+".pdf","PDF")
        ImgFile.close()
        file_size = os.path.getsize(name+".pdf")
        print(str(file_size//1000) + 'KB')
        if (file_size//1000) <= 225:
            self.makeEncrypt(name,name+".pdf")
            os.remove(name+".pdf") 
        else:
            print("ERROR")

    def textToPDF(self,path, name):
        pdf = FPDF() 
        pdf.add_page() 
        pdf.set_font("Arial", size = 15) 
        f = open(path, "r") 
        for x in f: 
            pdf.cell(200, 10, txt = x, ln = 1, align = 'L') 
        pdf.output(name+".pdf")
        file_size = os.path.getsize(name+".pdf")
        print(str(file_size//1000) + 'KB')
        if (file_size//1000) <= 225:
            self.makeEncrypt(name,name+".pdf")
            os.remove(name+".pdf") 
        else:
            print("ERROR")


    def makeEncrypt(self,name,path):
        id = '123456789123'
        date = '29'
        month = '03'
        year = '2000'
        fkey =base64.b64encode((id+id[::-1]+date+month+year).encode('utf-8'))
        cipher = Fernet(fkey)
        filename = path
        with open(filename,'rb')as f:
            e_file = f.read()
        encrypted_file = cipher.encrypt(e_file)
        with open(name + ".rv",'wb') as ef:
            ef.write(encrypted_file)



    def __init__(self,paths):
        path = str(paths).lower()
        name = path.rsplit('.', 1)[0]

        if not path.endswith(".pdf"):
                         
            if path.endswith(".docx"):
                self.wordToPDF(path,name)

            elif path.endswith(".png") or path.endswith(".jpg"):
                self.imageToPDF(path,name)
                
                
            elif path.endswith(".pptx") or path.endswith(".ppt"):
                self.pptToPDF(path,name)
                
            elif path.endswith(".txt"):
                self.textToPDF(path,name)
            else:
                print("No allowed")

        else:
            file_size = os.path.getsize(name+".pdf")
            if (file_size//1000) <= 225:
                self.makeEncrypt(name,name+".pdf")
                os.remove(name +".pdf") 
            else:
                print("ERROR")


    
ob = PDF_Converter(input())