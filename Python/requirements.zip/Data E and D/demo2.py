from cryptography.fernet import Fernet
import base64
import os

id = '123456789123'
date = '29'
month = '03'
year = '2000'


fkey =base64.b64encode((id+id[::-1]+date+month+year).encode('utf-8'))
# fkey = Fernet.generate_key()

cipher = Fernet(fkey)
filename = '1'

with open(filename+'.rv','rb') as df:
    encrypted_data = df.read()


decrypted_file = cipher.decrypt(encrypted_data)

with open(filename +'.pdf','wb') as df:
    df.write(decrypted_file)
    
os.remove(filename +".rv") 