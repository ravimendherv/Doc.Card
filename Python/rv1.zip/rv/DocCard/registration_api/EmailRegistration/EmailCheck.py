class EmailChecker:
    def __init__(self,email_id ):
        global data
        data = email_id
        print(data)

    
    def adder(self):        
        global get_list
        flag = 1
        with open("EmailList.txt", "r") as f:
                get_list = f.read()
                # print(get_list)
                # get_list = get_list.replace(get_list[0],"")
                # get_list = get_list.replace(get_list[-1],"")
                get_list = get_list.split(',')
                # print(get_list)
                # get_list = [i for i in get_list]

        # print(get_list)
        # print(type(get_list))
        if data not in get_list:
            flag = -1
        else:
            flag = 2

        if flag == -1:
            with open("EmailList.txt", "a") as f:
                # get_list.append(data)
                # print(get_list
                # print(get_list)
                f.write(data + ",") 
                return True
        else:
            return False
    # print(data)
    # print("Done")
    def checker(self):        
        global get_list1
        flag = 1
        with open("EmailList.txt", "r") as f:
                get_list1 = f.read()
                # print(get_list)
                # get_list = get_list.replace(get_list[0],"")
                # get_list = get_list.replace(get_list[-1],"")
                get_list1 = get_list1.split(',')
                # print(get_list)
                # get_list = [i for i in get_list]

        # print(get_list)
        # print(type(get_list))
        if data not in get_list1:
            return True
        else:
            return False

    def remover(self):        
        global get_list2
        flag = 1
        with open("EmailList.txt", "r") as f:
                get_list2 = f.read()
                # print(get_list)
                # get_list = get_list.replace(get_list[0],"")
                # get_list = get_list.replace(get_list[-1],"")
                get_list2 = get_list2.split(',')
                # print(get_list)
                # get_list = [i for i in get_list]

        # print(get_list)
        # print(type(get_list))
        print(data)
        if data not in get_list2:
            flag = -1
        else:
            flag = 2

        if flag == 2:
            fin = open("EmailList.txt", "rt")
            fdata = fin.read()
            fdata = fdata.replace(data+',','')
            fin.close()
            print("Hello_____")
            fin = open("EmailList.txt", "wt")
            fin.write(fdata)
            fin.close() 
            return True
        else:
            return False


# obj = EmailChecker("ravi@gmail.com")
# print(obj.remover())


