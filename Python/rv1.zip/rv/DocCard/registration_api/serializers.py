from rest_framework import serializers

from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from .models import SenderUserRegistrationModel, SenderKeyModel, ReceiverUserRegistrationModel
from django.http import HttpResponse

class UserRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','email', 'username', 'password','first_name', 'last_name']
        extra_kwargs = {'password':{'write_only':True},'email':{'write_only':True},'first_name':{'write_only':True}, 'last_name':{'write_only':True}}
    def create(self,validate_date):
        user = User.objects.create_user(**validate_date)
        # Token.objects.create(user = user)
        return user

class UserNameSenderSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email','username']
        extra_kwargs = {'email':{'write_only':True},'username':{'read_only':True}}

class UserEmailVerificationAtRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email']
        extra_kwargs = {'email':{'write_only':True}}

class SmsVerificationAtRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = SenderUserRegistrationModel
        fields = ['mobile_no']
        extra_kwargs = {'mobile_no':{'write_only':True}}
        

class SenderRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = SenderUserRegistrationModel
        fields = ['id', 'doc_id', 'f_name', 'l_name', 'email_id', 'mobile_no', 'dob', 'user_type', 'gender']
        extra_kwargs = {'f_name':{'write_only':True},'l_name':{'write_only':True},'email_id':{'write_only':True},'mobile_no':{'write_only':True},'dob':{'write_only':True},'user_type':{'write_only':True},'gender':{'write_only':True}}

class ReceicerRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReceiverUserRegistrationModel
        fields = ['id', 'doc_id', 'f_name', 'l_name', 'email_id', 'mobile_no', 'dob', 'user_type', 'gender']
        extra_kwargs = {'doc_id':{'write_only':True},'f_name':{'write_only':True},'l_name':{'write_only':True},'email_id':{'write_only':True},'mobile_no':{'write_only':True},'dob':{'write_only':True},'user_type':{'write_only':True},'gender':{'write_only':True}}

class SenderKeySerializer(serializers.ModelSerializer):
    class Meta:
        model = SenderKeyModel
        fields = ['id', 'doc_id', 'date', 'month', 'year']
        extra_kwargs = {'doc_id':{'write_only':True},'date':{'write_only':True},'month':{'write_only':True},'year':{'write_only':True}}

        
        
        