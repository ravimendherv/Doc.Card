from django.db import models

# Create your models here.



       
class SenderUserRegistrationModel(models.Model):
    id = models.IntegerField(primary_key=True, serialize=False)
    doc_id = models.BigIntegerField(unique=True)
    f_name = models.CharField(max_length=20)
    l_name = models.CharField(max_length=20)
    email_id = models.EmailField(max_length=30, unique=True)
    mobile_no = models.BigIntegerField(unique=True)
    dob = models.DateField()
    user_type = models.IntegerField()
    gender = models.IntegerField()
    date_of_registration = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.doc_id

class ReceiverUserRegistrationModel(models.Model):
    id = models.IntegerField(primary_key=True, serialize=False)
    doc_id = models.BigIntegerField(unique=True)
    f_name = models.CharField(max_length=20)
    l_name = models.CharField(max_length=20)
    email_id = models.EmailField(max_length=30, unique=True)
    mobile_no = models.BigIntegerField(unique=True)
    dob = models.DateField()
    user_type = models.IntegerField()
    gender = models.IntegerField()
    date_of_registration = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.doc_id


class SenderKeyModel(models.Model):
    id = models.IntegerField(primary_key=True, serialize=False)
    doc_id = models.BigIntegerField(unique=True)
    date = models.CharField(max_length=2)
    month = models.CharField(max_length=2)
    year = models.CharField(max_length=4)

    def __str__(self):
        return self.doc_id

