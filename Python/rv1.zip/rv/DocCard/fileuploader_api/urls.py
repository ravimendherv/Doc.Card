from django.urls import path, include
from .views import FileUploardView, FileDownloaderView, FileDeleterView, ZipFileDeleterView
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('FileUploadView', FileUploardView)
router.register('FileDownloaderView',FileDownloaderView)
router.register('FileDeleterView', FileDeleterView)
router.register('ZipFileDeleterView',ZipFileDeleterView)



urlpatterns = [
    path('',include(router.urls)),
    # path('user_create',user_post),

]
