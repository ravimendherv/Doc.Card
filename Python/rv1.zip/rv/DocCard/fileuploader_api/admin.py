from django.contrib import admin
from .models import UploardFileModel
# Register your models here.


@admin.register(UploardFileModel)
class UploadFileAdmin(admin.ModelAdmin):
    list_display = ['doc_id','input_file','file_name','timestamp']