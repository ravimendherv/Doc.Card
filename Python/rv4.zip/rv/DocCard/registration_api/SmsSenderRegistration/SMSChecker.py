class SMSChecker: 
    def __init__(self,phoneNo):
        global data
        self.data = phoneNo

    def binary_search(self,arr, x):
        low = 0
        high = len(arr) - 1
        mid = 0 
        while low <= high:
            mid = (high + low) // 2
            if arr[mid] < x:
                low = mid + 1
            elif arr[mid] > x:
                high = mid - 1
            else:
                return 1
        return -1

    def main(self):
        global get_list
        # print(self.data)        
        flag = 1
        with open("smsList.txt", "r") as f:     
            get_list = f.read()
            get_list = get_list.replace(get_list[0],"",1)
            get_list = get_list.replace(get_list[-1],"",1)
            get_list = get_list.split(',')
            get_list = [int(i) for i in get_list]

        flag = self.binary_search(get_list, self.data)
        if flag == -1:
            with open("smsList.txt", "w") as f:
                get_list.append(self.data)
                get_list.sort()
                f.write(str(get_list))
            return True
        else:
            return False

    def checker(self):
        global get_list1
        # print(self.data)        
        flag = 1
        with open("smsList.txt", "r") as f:     
            get_list1 = f.read()
            get_list1 = get_list1.replace(get_list1[0],"",1)
            get_list1 = get_list1.replace(get_list1[-1],"",1)
            get_list1 = get_list1.split(',')
            get_list1 = [int(i) for i in get_list1]

        flag = self.binary_search(get_list1, self.data)
        if flag == -1:
            return True
        else:
            return False


    def main1(self):
        global get_list2
        print(self.data, "________________________")        
        flag = 1
        with open("smsList.txt", "r") as f:     
            get_list2 = f.read()
            get_list2 = get_list2.replace(get_list2[0],"",1)
            get_list2 = get_list2.replace(get_list2[-1],"",1)
            get_list2 = get_list2.split(',')
            get_list2 = [int(i) for i in get_list2]

        flag = self.binary_search(get_list2, self.data)
        if flag == 1:
            with open("smsList.txt", "w") as f:
                get_list2.remove(self.data)
                get_list2.sort()
                f.write(str(get_list2))
            return True
        else:
            return False
    
# obj = SMSChecker(9404877317)
# print(obj.main1())

