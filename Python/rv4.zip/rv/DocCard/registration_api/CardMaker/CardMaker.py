from PIL import Image, ImageDraw, ImageFont
import datetime
import random
class CardMaker:
    def __init__(self, num, name, loc, dir):
        self.num = num
        self.name = name
        self.loc = loc
        self.dir = dir

    def cardgenrator(self):
        c = str(random.randint(1,6))
        frontSide = Image.open(self.dir + c+"_1.png")
        backSide = Image.open(self.dir + c+"_2.png")
        qrCode = Image.open(self.loc + "QRCode.png").resize((140,140), Image.ANTIALIAS)
        barCode = Image.open(self.loc + "BarCode.png").resize((282,164),Image.ANTIALIAS)
        drawOnFrontSide = ImageDraw.Draw(frontSide)
        drawOnBackSide = ImageDraw.Draw(backSide)
        numberFont = ImageFont.truetype("agencyfb-bold.otf",size=38)
        nameFont = ImageFont.truetype("agencyfb-bold.otf",size=22)
        frontSide.paste(qrCode, (30,198,170,338))
        backSide.paste(barCode, (170,125,452,289))
        # def cardMaker(n,name):    
        # num = n
        n = "  ".join(self.num[i:i+3] for i in range(0, len(self.num), 3))
        n = " ".join(n)
        x = datetime.datetime.now()
        m = x.month
        y = x.year + 1
        date = str(m)+"/"+str(y) if m>9 else "0"+str(m)+"/"+str(y)
        drawOnFrontSide.text((25,106), n, font=numberFont)
        drawOnFrontSide.text((190,235), self.name, font=nameFont)
        drawOnFrontSide.text((420,235), date, font=nameFont)
        frontSide.save(self.loc + "CardFrontSide.png")
        backSide.save(self.loc + "CardBackSide.png")

# obj = CardMaker("123412341234","Ravi Mendhe")
# obj.cardgenrator()



