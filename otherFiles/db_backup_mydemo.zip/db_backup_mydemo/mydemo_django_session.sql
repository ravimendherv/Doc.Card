-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: mydemo
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('088g4x12m46gqdr9qy1d044whhqseaui','.eJxVjMsOwiAQRf-FtSFlykNcuu83EIYZpGogKe3K-O_apAvd3nPOfYkQt7WErfMSZhIXocTpd8OYHlx3QPdYb02mVtdlRrkr8qBdTo34eT3cv4MSe_nWZrQI1gIyaEWDMQ60sz4r70fW7LTJnIczj0DaWOcRvaUMkVC5hAnE-wO5OTeE:1lWv5t:XS_dlL9ehPUfxUNnz7v8yoVGM3ZnoPxPqItE40vWiLQ','2021-04-29 06:03:13.236433'),('0blydbr1vbhkoewjfnrl8vgnwijcnamu','.eJxVjDsOwjAQBe_iGlkrr7-U9JzBWttrHECOFCcV4u4QKQW0b2beS0Ta1ha3wUucijgLBeL0OybKD-47KXfqt1nmua_LlOSuyIMOeZ0LPy-H-3fQaLRvjdXmogGoQiWtk3PG55CCIuutxwqZWbPV4F3N3qNCRqwmWUjOmMDi_QELSTfp:1m2XJT:HJ1e4O9mqTmR1TxqNTEazSUCHokvzmYXV-z1lZgVFDM','2021-07-25 11:07:55.536306'),('5kofiavqse8drdz8vss9ifp5siqt1br0','.eJxVjDsOwjAQBe_iGlkrr7-U9JzBWttrHECOFCcV4u4QKQW0b2beS0Ta1ha3wUucijgLBeL0OybKD-47KXfqt1nmua_LlOSuyIMOeZ0LPy-H-3fQaLRvjdXmogGoQiWtk3PG55CCIuutxwqZWbPV4F3N3qNCRqwmWUjOmMDi_QELSTfp:1mVWtz:3AzizdfSprUJkIe7yUY7cJdc9chB_dr2mb1qqSg-_LI','2021-10-13 10:33:27.141224'),('74a4syyjmhwjgbpw2isj72ycy5xogzku','.eJxVjDsOwjAQBe_iGlkrr7-U9JzBWttrHECOFCcV4u4QKQW0b2beS0Ta1ha3wUucijgLBeL0OybKD-47KXfqt1nmua_LlOSuyIMOeZ0LPy-H-3fQaLRvjdXmogGoQiWtk3PG55CCIuutxwqZWbPV4F3N3qNCRqwmWUjOmMDi_QELSTfp:1mvvMF:MQWDthmKaiKPsuwWxvsADs721_UDTDoqJ-Eu2UOh5Tw','2021-12-25 05:55:43.229643'),('74x3oymtwhsp4w2nciror4whp7qqrfsr','.eJxVjMsOwiAQRf-FtSFlykNcuu83EIYZpGogKe3K-O_apAvd3nPOfYkQt7WErfMSZhIXocTpd8OYHlx3QPdYb02mVtdlRrkr8qBdTo34eT3cv4MSe_nWZrQI1gIyaEWDMQ60sz4r70fW7LTJnIczj0DaWOcRvaUMkVC5hAnE-wO5OTeE:1ldJbe:q_Fgvo9bboi0f6Mp0asiC7FYvtfGFGt4N5nNEX17bUI','2021-05-16 21:26:26.229580'),('9st6jdunj7jc44ybm5au032hqjmumh5p','.eJxVjMsOwiAQRf-FtSFlykNcuu83EIYZpGogKe3K-O_apAvd3nPOfYkQt7WErfMSZhIXocTpd8OYHlx3QPdYb02mVtdlRrkr8qBdTo34eT3cv4MSe_nWZrQI1gIyaEWDMQ60sz4r70fW7LTJnIczj0DaWOcRvaUMkVC5hAnE-wO5OTeE:1lV6I8:_8e5Ymesxqkn8OeUGP-GwHwrgqIPDHa6KE9xmNXZkps','2021-04-24 05:36:20.931896'),('kms8bsqcoxsscga0t63cgt9aldyra8es','.eJxVjMsOwiAQRf-FtSFlykNcuu83EIYZpGogKe3K-O_apAvd3nPOfYkQt7WErfMSZhIXocTpd8OYHlx3QPdYb02mVtdlRrkr8qBdTo34eT3cv4MSe_nWZrQI1gIyaEWDMQ60sz4r70fW7LTJnIczj0DaWOcRvaUMkVC5hAnE-wO5OTeE:1lTJaE:5DEpMqnmRnAtpASrgHULMymRPJoHcMo0X4PbntyqlrQ','2021-04-19 07:23:38.625993'),('ttrbbx2y7aymm2w8ji9b483pml4vqqzc','.eJxVjMsOwiAQRf-FtSFlykNcuu83EIYZpGogKe3K-O_apAvd3nPOfYkQt7WErfMSZhIXocTpd8OYHlx3QPdYb02mVtdlRrkr8qBdTo34eT3cv4MSe_nWZrQI1gIyaEWDMQ60sz4r70fW7LTJnIczj0DaWOcRvaUMkVC5hAnE-wO5OTeE:1laDXP:lrqTFtxoxNVQA9ZtSpA_j2lGILhliMVuKqdAtRw_iGQ','2021-05-08 08:21:15.589794'),('u5gjx8modbiy20qmn74jw2113s0516id','.eJxVjMsOwiAQRf-FtSFlykNcuu83EIYZpGogKe3K-O_apAvd3nPOfYkQt7WErfMSZhIXocTpd8OYHlx3QPdYb02mVtdlRrkr8qBdTo34eT3cv4MSe_nWZrQI1gIyaEWDMQ60sz4r70fW7LTJnIczj0DaWOcRvaUMkVC5hAnE-wO5OTeE:1lS8T6:wJoEhxpCNs2SN2oPSiC9DoRwotkA9YS1u8KpJsnvAMs','2021-04-16 01:19:24.841724');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-25 17:08:28
