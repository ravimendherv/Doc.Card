-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: mydemo
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2021-03-27 22:59:54.460726','7','149053793502',3,'',4,1),(2,'2021-03-27 23:00:01.166945','4','273586218139',3,'',4,1),(3,'2021-03-27 23:00:07.949821','9','341730607105',3,'',4,1),(4,'2021-03-27 23:00:15.336229','2','364573290190',3,'',4,1),(5,'2021-03-27 23:00:23.429683','3','374203571146',3,'',4,1),(6,'2021-03-27 23:00:30.204253','10','400422071534',3,'',4,1),(7,'2021-03-27 23:00:40.766033','5','469758626822',3,'',4,1),(8,'2021-03-27 23:00:47.579182','8','610061565133',3,'',4,1),(9,'2021-03-27 23:00:54.925062','6','960687889123',3,'',4,1),(10,'2021-03-27 23:03:17.071531','11','9a0c5dab5524de3b7038e50d784af151b9490220',1,'[{\"added\": {}}]',8,1),(11,'2021-03-27 23:03:35.197453','1','c0dc5336d06d9ce24affb7afb586fb022b18a221',1,'[{\"added\": {}}]',8,1),(12,'2021-03-30 05:17:56.572274','14','149872094419',3,'',4,1),(13,'2021-03-30 05:18:06.315653','12','218596427882',3,'',4,1),(14,'2021-03-30 05:18:14.251377','15','649476679292',3,'',4,1),(15,'2021-03-30 05:18:22.268646','13','707792697170',3,'',4,1),(16,'2021-03-30 05:18:30.355740','11','830772629852',3,'',4,1),(17,'2021-03-30 06:15:28.642690','17','428968359754',3,'',4,1),(18,'2021-03-30 06:15:38.321150','16','971295931376',3,'',4,1),(19,'2021-03-31 02:49:04.438623','19','407984381419',3,'',4,1),(20,'2021-03-31 02:49:25.884975','18','964255209460',3,'',4,1),(21,'2021-03-31 03:13:39.528341','20','royalvision',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\", \"Email address\", \"Superuser status\"]}}]',4,1),(22,'2021-03-31 03:14:15.500434','1','ravimendhe',2,'[]',4,1),(23,'2021-03-31 03:14:31.724965','20','19a3a8abc903cef814ded8a8b26cc38aad2430ea',1,'[{\"added\": {}}]',8,1),(24,'2021-03-31 03:17:41.110605','20','royalvision',2,'[{\"changed\": {\"fields\": [\"User permissions\"]}}]',4,1),(25,'2021-03-31 03:20:26.191455','20','19a3a8abc903cef814ded8a8b26cc38aad2430ea',3,'',8,1),(26,'2021-03-31 03:20:35.255633','20','fbbe24eef43daf810642cd829f5fcb418c61f14d',1,'[{\"added\": {}}]',8,1),(27,'2021-03-31 03:20:41.044862','1','c0dc5336d06d9ce24affb7afb586fb022b18a221',3,'',8,1),(28,'2021-03-31 03:20:49.505517','1','58e0ef38df7d3a2b843741fa4e42849c19b87f41',1,'[{\"added\": {}}]',8,1),(29,'2021-04-10 05:38:21.395586','26','138165416946',3,'',4,1),(30,'2021-04-10 05:38:34.981824','25','588446091840',3,'',4,1),(31,'2021-04-10 05:38:50.306487','27','905063725010',3,'',4,1),(32,'2021-04-15 22:40:18.765262','29','998144819893',3,'',4,1),(33,'2021-04-15 22:40:26.923130','37','899905981795',3,'',4,1),(34,'2021-04-15 22:40:35.615209','31','896075178576',3,'',4,1),(35,'2021-04-15 22:40:43.495251','36','843148383761',3,'',4,1),(36,'2021-04-15 22:40:50.758591','39','801554843811',3,'',4,1),(37,'2021-04-15 22:40:57.935493','32','699464177420',3,'',4,1),(38,'2021-04-15 22:41:05.587010','22','693805762547',3,'',4,1),(39,'2021-04-15 22:41:12.036847','21','687832316147',3,'',4,1),(40,'2021-04-15 22:41:18.630728','41','548631424374',3,'',4,1),(41,'2021-04-15 22:41:24.993655','40','487847751370',3,'',4,1),(42,'2021-04-15 22:41:31.439583','35','429562689230',3,'',4,1),(43,'2021-04-15 22:41:40.426590','23','354472668849',3,'',4,1),(44,'2021-04-15 22:41:47.876926','30','318770869146',3,'',4,1),(45,'2021-04-15 22:41:53.960546','28','251942478268',3,'',4,1),(46,'2021-04-15 22:42:01.036379','38','244774135984',3,'',4,1),(47,'2021-04-15 22:42:08.234768','34','234513556482',3,'',4,1),(48,'2021-04-15 22:42:14.589880','33','228811364916',3,'',4,1),(49,'2021-04-15 22:42:22.815146','24','109677101076',3,'',4,1),(50,'2021-04-16 07:09:33.912472','43','801508166163',3,'',4,1),(51,'2021-04-16 07:20:51.985071','44','266528777853',3,'',4,1),(52,'2021-04-16 07:36:25.753781','45','940432672179',3,'',4,1),(53,'2021-04-16 08:04:39.256196','47','672895298649',3,'',4,1),(54,'2021-04-24 08:24:39.303417','20','royalvision',2,'[{\"changed\": {\"fields\": [\"User permissions\"]}}]',4,1),(55,'2021-05-02 21:26:25.308660','42','698275697749',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,1),(56,'2021-07-11 12:12:16.268756','20','royalvision',2,'[{\"changed\": {\"fields\": [\"Superuser status\", \"User permissions\"]}}]',4,20),(57,'2021-07-11 12:12:44.990500','48','587877545248',3,'',4,20),(58,'2021-07-11 15:05:03.048829','49','694237769403',3,'',4,20),(59,'2021-07-11 15:19:10.126471','50','346528147758',3,'',4,20),(60,'2021-09-29 11:30:51.020684','1','RFID_Data_Model object (1)',1,'[{\"added\": {}}]',14,20);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-25 17:08:33
